/*
 * FMCES create & edit pages: self-check (v1)
 * ------------------------------------------------------------
 * Run it on every page and state listed in PROMPT.md §10, in the browser where the app runs (http://localhost:8001).
 *
 *   1. Paste this whole file into the browser console (or evaluate it with your browser tool).
 *   2. Then run:   await lpFormVerify()
 *
 * It prints PASS / FAIL / WARN / INFO for each check with the expected and the actual value,
 * shows a panel in the bottom-right corner of the page, and returns a summary object
 * ({ form, mode, pass, fail, warn, summary, problems }). Also saved as window.__lpFormVerifyLast.
 *
 * Options: await lpFormVerify({ overlay: false })   – no panel
 *          await lpFormVerify({ highlight: true })  – outline failing elements in red
 */
(function () {
  const TOKENS = { '--bg': '#0F1A22', '--accent': '#2DD4BF', '--accent2': '#5EEAD4', '--text': '#E6EEF2', '--muted': '#86A0AE', '--card': '#152733', '--border': '#23394A' };
  const C = {
    accent: 'rgb(45, 212, 191)', on: 'rgb(6, 42, 38)', text: 'rgb(230, 238, 242)', text2: 'rgb(167, 184, 196)', muted: 'rgb(134, 160, 174)', err: 'rgb(244, 163, 163)',
    accent2: 'rgb(94, 234, 212)', border: 'rgb(35, 57, 74)', btn: 'rgb(43, 69, 86)', transparent: 'rgba(0, 0, 0, 0)', inbg: 'rgba(15, 26, 34, 0.62)', draft: 'rgb(246, 193, 119)'
  };
  const FORMS = { application: 3, itam: 1, feature: 2, action: 2, profile: 3, policy: 3, entitlement: 3, account: 2 };

  async function lpFormVerify(opts) {
    opts = Object.assign({ overlay: true, highlight: false }, opts || {});
    await new Promise((res) => setTimeout(res, 700)); // let entrance animations and transitions settle
    const R = [];
    const add = (status, area, check, expected, actual, el) => R.push({ status, area, check, expected: expected === undefined ? '' : String(expected), actual: actual === undefined ? '' : String(actual), el: el || null });
    const ok = (cond, area, check, expected, actual, el, soft) => add(cond ? 'PASS' : (soft ? 'WARN' : 'FAIL'), area, check, expected, actual, el);
    const $ = (s, r) => (r || document).querySelector(s);
    const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
    const cs = (el) => getComputedStyle(el);
    const n = (v) => Math.round(parseFloat(v) * 10) / 10;
    const near = (a, b, t) => Math.abs(parseFloat(a) - b) <= (t === undefined ? 1 : t);
    const vis = (el) => !!el && el.getClientRects().length > 0 && cs(el).visibility !== 'hidden';
    const txt = (el) => (el ? el.textContent.replace(/\s+/g, ' ').trim() : '');
    const path = (el) => {
      if (!el) return '';
      const parts = []; let e = el;
      for (let i = 0; e && e.nodeType === 1 && i < 3; i++, e = e.parentElement) {
        const cl = Array.from(e.classList || []).slice(0, 3).join('.');
        parts.unshift(e.tagName.toLowerCase() + (cl ? '.' + cl : ''));
      }
      return parts.join(' > ');
    };
    let form = '?', mode = '?', state = '';

    // ---------- root
    const root = $$('.lp-root').find((r) => r.hasAttribute('data-lp-form')) || null;
    ok(!!root, 'Setup', 'Wrapper <div class="lp-root" data-lp-form="…" data-lp-mode="create|edit"> around the page content', 'present', root ? 'present' : 'missing');
    if (!root) return finish();
    form = root.getAttribute('data-lp-form'); mode = root.getAttribute('data-lp-mode');
    ok(Object.prototype.hasOwnProperty.call(FORMS, form), 'Setup', 'data-lp-form is one of ' + Object.keys(FORMS).join(', '), Object.keys(FORMS).join('|'), form);
    ok(mode === 'create' || mode === 'edit', 'Setup', 'data-lp-mode is create or edit', 'create|edit', mode);
    const edit = mode === 'edit';

    // ---------- stylesheets + tokens
    const rcs = cs(root);
    Object.keys(TOKENS).forEach((k) => {
      const v = rcs.getPropertyValue(k).trim().toUpperCase();
      ok(v === TOKENS[k], 'Stylesheet', 'Token ' + k + ' on .lp-root (fmces-pages.css loaded)', TOKENS[k], v || '(empty)');
    });
    const probe = document.createElement('div'); probe.style.cssText = 'position:absolute;left:-9999px;top:0';
    probe.innerHTML = '<button class="lp-btn lp-btn-p">x</button><section class="lp-cf-sc"></section><div class="lp-cf-ab"></div>';
    root.appendChild(probe);
    ok(cs(probe.children[0]).backgroundColor === C.accent, 'Stylesheet', 'fmces-pages.css rules apply (a test .lp-btn.lp-btn-p is teal)', C.accent, cs(probe.children[0]).backgroundColor);
    ok(near(cs(probe.children[1]).borderTopLeftRadius, 18), 'Stylesheet', 'fmces-forms.css is loaded (a test .lp-cf-sc has an 18px radius)', '18px', cs(probe.children[1]).borderTopLeftRadius);
    ok(cs(probe.children[2]).position === 'sticky', 'Stylesheet', 'fmces-forms.css is unedited (a test .lp-cf-ab is sticky)', 'sticky', cs(probe.children[2]).position);
    probe.remove();

    // ---------- fonts
    if (document.fonts && document.fonts.ready) { try { await document.fonts.ready; } catch (e) { /* ignore */ } }
    ok(/Manrope/i.test(rcs.fontFamily), 'Fonts', 'Manrope is the font of .lp-root', 'Manrope…', rcs.fontFamily);
    const manropeOk = document.fonts ? Array.from(document.fonts).some((f) => /Manrope/i.test(f.family) && f.status === 'loaded') : true;
    ok(manropeOk, 'Fonts', 'Manrope webfont is actually loaded (weights 200–800)', 'loaded', manropeOk ? 'loaded' : 'not loaded – add the Google Fonts link from PROMPT.md');
    const monoOk = document.fonts ? Array.from(document.fonts).some((f) => /JetBrains Mono/i.test(f.family) && f.status === 'loaded') : true;
    ok(monoOk, 'Fonts', 'JetBrains Mono webfont is loaded', 'loaded', monoOk ? 'loaded' : 'not loaded', null, true);

    // ---------- page wrapper + header
    ok(!!$('.lp-pg', root), 'Page', '.lp-pg wrapper inside .lp-root', 'present', $('.lp-pg', root) ? 'present' : 'missing');
    const aur = $('.lp-aur', root);
    ok(!!aur && $$('i', aur).length === 2, 'Page', 'Background glow .lp-aur with two <i> blobs', '2 blobs', aur ? $$('i', aur).length + ' blobs' : 'missing');
    const hd = $('.lp-ph.lp-cf-hd', root);
    ok(!!hd, 'Header', 'Page header .lp-ph.lp-cf-hd (not the old header)', 'present', hd ? 'present' : 'missing');
    const pt = $('.lp-pt', root);
    if (pt) {
      const tsz = window.matchMedia('(max-width: 900px)').matches ? 28 : 36;
      ok(near(cs(pt).fontSize, tsz) && cs(pt).fontWeight === '300', 'Header', 'Title .lp-pt is ' + tsz + 'px / 300', tsz + 'px / 300', cs(pt).fontSize + ' / ' + cs(pt).fontWeight, pt);
      ok(cs(pt).color === C.text, 'Header', 'Title colour', C.text, cs(pt).color, pt);
    } else ok(false, 'Header', 'Title .lp-pt', 'present', 'missing');
    ok(!!$('.lp-eb .lp-cf-bk', root), 'Header', 'Back button .lp-cf-bk in the eyebrow', 'present', $('.lp-eb .lp-cf-bk', root) ? 'present' : 'missing');
    const eb = $('.lp-eb > b', root);
    ok(!!eb && /^\d\d$/.test(txt(eb)), 'Header', 'Eyebrow module number like "01"', '01–05', eb ? txt(eb) : 'missing');
    const bign = $('.lp-bign', root);
    ok(!!bign && eb && txt(bign) === txt(eb), 'Header', 'Watermark number .lp-bign matches the eyebrow', eb ? txt(eb) : '01–05', bign ? txt(bign) : 'missing');
    const crumb = $('.lp-eb .lp-cf-crumb', root);
    ok(!!crumb, 'Header', 'Breadcrumb .lp-cf-crumb in the eyebrow ("FMCES / … / New|Edit")', 'present', crumb ? txt(crumb) : 'missing');
    const st = $('.lp-cf-hr .lp-cf-st', root);
    ok(!!st, 'Header', 'Status pill .lp-cf-st at the right of the header', 'present', st ? txt(st) : 'missing');
    if (edit) {
      ok(!!$('.lp-ps .lp-cf-rec', root), 'Header', 'Edit: record chip .lp-cf-rec under the title (name, status, version)', 'present', $('.lp-ps .lp-cf-rec', root) ? txt($('.lp-ps .lp-cf-rec', root)) : 'missing');
      ok(!!st && st.classList.contains('lp-draft'), 'Header', 'Edit: status pill is lp-draft ("Editing …")', 'lp-draft', st ? st.className : 'missing', st);
    }

    // ---------- layout
    const wrap = $('.lp-cf-wrap', root), main = $('.lp-cf-main', root), rail = $('.lp-cf-rail', root);
    ok(!!wrap && !!main && !!rail, 'Layout', 'Two columns: .lp-cf-wrap > .lp-cf-main + aside.lp-cf-rail', 'present', (wrap ? 'wrap ' : '') + (main ? 'main ' : '') + (rail ? 'rail' : '') || 'missing');
    if (!main || !rail) return finish();
    if (window.innerWidth > 1100) {
      ok(near(rail.getBoundingClientRect().width, 316, 2), 'Layout', 'Rail width at desktop', '316px', n(rail.getBoundingClientRect().width) + 'px', rail);
      ok(cs(rail).position === 'sticky', 'Layout', 'Rail is sticky', 'sticky', cs(rail).position, rail);
    }

    // ---------- sections
    const secs = $$(':scope > .lp-cf-sc, :scope > .lp-cf-ge', main);
    const want = FORMS[form] || 1;
    ok(secs.length === want, 'Sections', 'Number of section cards (.lp-cf-sc / .lp-cf-ge) for ' + form, want, secs.length, main);
    secs.forEach((s, i) => {
      const c = cs(s);
      ok(/linear-gradient/.test(c.backgroundImage) && near(c.borderTopLeftRadius, 18), 'Sections', 'Section ' + (i + 1) + ': gradient card, 18px radius', 'linear-gradient, 18px', c.backgroundImage.slice(0, 30) + ', ' + c.borderTopLeftRadius, s);
      const sn = $('.lp-cf-sh .lp-cf-sn', s);
      ok(!!sn && near(cs(sn).width, 30), 'Sections', 'Section ' + (i + 1) + ': numbered step .lp-cf-sn (30px circle)', '30px', sn ? cs(sn).width : 'missing', sn || s);
      const h2 = $('.lp-cf-stt h2', s);
      ok(!!h2 && near(cs(h2).fontSize, 15.5, 0.3) && cs(h2).fontWeight === '700', 'Sections', 'Section ' + (i + 1) + ': title 15.5px / 700 with a sub-line', '15.5px / 700', h2 ? cs(h2).fontSize + ' / ' + cs(h2).fontWeight : 'missing', h2 || s);
      ok(!!$('.lp-cf-stt p', s), 'Sections', 'Section ' + (i + 1) + ': one-line description under the title', 'present', $('.lp-cf-stt p', s) ? txt($('.lp-cf-stt p', s)) : 'missing', s, true);
      ok(!!$('.lp-cf-shr .lp-cf-pl', s), 'Sections', 'Section ' + (i + 1) + ': status pill .lp-cf-pl at the right ("3 of 6", "Optional", "1 issue"…)', 'present', $('.lp-cf-shr .lp-cf-pl', s) ? txt($('.lp-cf-shr .lp-cf-pl', s)) : 'missing', s);
    });
    ok($$('.lp-cf-sc.lp-act', main).length <= 1, 'Sections', 'At most one active section (.lp-act)', '≤ 1', $$('.lp-cf-sc.lp-act', main).length);

    // ---------- fields
    const labels = $$('.lp-cf-l', main).filter(vis);
    if (labels[0]) ok(near(cs(labels[0]).fontSize, 12) && cs(labels[0]).fontWeight === '700' && cs(labels[0]).color === C.text2, 'Fields', 'Labels .lp-cf-l 12px / 700 / #A7B8C4', '12px 700 ' + C.text2, cs(labels[0]).fontSize + ' ' + cs(labels[0]).fontWeight + ' ' + cs(labels[0]).color, labels[0]);
    const rq = $('.lp-cf-rq', main);
    if (rq) ok(cs(rq).color === C.err, 'Fields', 'Required asterisk .lp-cf-rq is #F4A3A3', C.err, cs(rq).color, rq);
    const ins = $$('.lp-cf-in', main).filter(vis);
    const plainIn = ins.find((x) => !/lp-(fo|inv|chg)/.test(x.className) && x.tagName === 'INPUT' && document.activeElement !== x && !x.matches(':hover'));
    if (plainIn) {
      const c = cs(plainIn);
      ok(near(plainIn.getBoundingClientRect().height, 44, 1.5), 'Fields', 'Text input height', '44px', n(plainIn.getBoundingClientRect().height) + 'px', plainIn);
      ok(near(c.borderTopLeftRadius, 10) && c.borderTopColor === C.btn, 'Fields', 'Text input: 10px radius, #2B4556 border', '10px, ' + C.btn, c.borderTopLeftRadius + ', ' + c.borderTopColor, plainIn);
      ok(c.backgroundColor === C.inbg, 'Fields', 'Text input background', C.inbg, c.backgroundColor, plainIn);
    }
    $$('.lp-cf-sl', main).filter(vis).slice(0, 3).forEach((sl) => ok(near(sl.getBoundingClientRect().height, 44, 1.5), 'Fields', 'Select trigger .lp-cf-sl height', '44px', n(sl.getBoundingClientRect().height) + 'px', sl));
    const stray = $$('input:not([type=checkbox]):not([type=radio]):not([type=hidden]):not([type=file]), textarea, select', main).filter(vis)
      .filter((x) => !x.closest('.lp-psr, .lp-sr, .lp-qs, .lp-cf-sw, .lp-cf-dd') && !/lp-cf-in|lp-cf-ci|lp-mini/.test(x.className));
    ok(stray.length === 0, 'Fields', 'Every input / textarea / select uses .lp-cf-in (or .lp-cf-ci in the grid) — no library-styled fields left', '0', stray.length + (stray.length ? ' e.g. ' + path(stray[0]) : ''), stray[0]);
    const strayBtn = $$('button', main).concat($$('button', rail)).filter(vis).filter((b) => !Array.from(b.classList).some((c) => c.indexOf('lp-') === 0) && !(b.parentElement && Array.from(b.parentElement.classList).some((c) => c.indexOf('lp-') === 0)));
    ok(strayBtn.length === 0, 'Fields', 'Every button uses lp- classes (no library buttons)', '0', strayBtn.length + (strayBtn.length ? ' e.g. "' + txt(strayBtn[0]) + '"' : ''), strayBtn[0]);
    $$('.lp-cf-ta', main).filter(vis).slice(0, 1).forEach((t) => ok(t.getBoundingClientRect().height >= 90, 'Fields', 'Textarea min height', '≥ 92px', n(t.getBoundingClientRect().height) + 'px', t));

    // ---------- rail
    const prog = $$('.lp-cf-rc', rail).find((c) => $('.lp-cf-pn', c));
    ok(!!prog, 'Rail', 'Progress card (.lp-cf-rc with .lp-cf-pn big count)', 'present', prog ? 'present' : 'missing', rail);
    if (prog) {
      const big = $('.lp-cf-pn b', prog);
      ok(!!big && near(cs(big).fontSize, 40) && cs(big).fontWeight === '200', 'Rail', 'Progress number 40px / 200', '40px / 200', big ? cs(big).fontSize + ' / ' + cs(big).fontWeight : 'missing', big);
      ok($$('.lp-cf-pb i', prog).length >= 1, 'Rail', 'Segmented progress bar .lp-cf-pb (one <i> per required item)', '≥ 1', $$('.lp-cf-pb i', prog).length, prog);
      const rows = $$('.lp-cf-pr', prog);
      const gridRows = $$('.lp-cf-gr:not(.lp-hd)', main).length;
      const expectRows = (!edit && (form === 'feature' || form === 'action')) ? gridRows : secs.length;
      ok(rows.length === expectRows, 'Rail', 'Progress list has one row per ' + ((!edit && (form === 'feature' || form === 'action')) ? 'grid row' : 'section'), expectRows, rows.length, prog);
    }
    if (form === 'account') ok(!!$('.lp-cf-sum', rail), 'Rail', 'Account: Summary card .lp-cf-sum', 'present', $('.lp-cf-sum', rail) ? 'present' : 'missing');
    else {
      const tl = $$('.lp-cf-tl .lp-cf-tlr', rail);
      ok(tl.length === 4, 'Rail', (edit ? 'When you submit' : 'After you submit') + ' lifecycle with 4 steps', 4, tl.length, rail);
      ok($$('.lp-cf-tlr.lp-cur', rail).length === 1, 'Rail', 'Exactly one current lifecycle step (.lp-cur, "You are here")', 1, $$('.lp-cf-tlr.lp-cur', rail).length, rail);
    }
    if (!edit && (form === 'feature' || form === 'action')) ok(!!$('.lp-cf-xl', rail), 'Rail', 'Paste from Excel tips card (.lp-cf-xl)', 'present', $('.lp-cf-xl', rail) ? 'present' : 'missing', rail);
    if (edit) {
      const chs = $$('.lp-cf-chl .lp-cf-chr', rail);
      const marks = $$('.lp-cf-ch, .lp-chg, .lp-chgr, .lp-cf-cr.lp-new, .lp-cf-it.lp-new, .lp-cf-mxc.lp-chg', main).length;
      ok(!!$('.lp-cf-chl', rail), 'Edit', 'Your changes card (.lp-cf-chl) at the top of the rail', 'present', $('.lp-cf-chl', rail) ? chs.length + ' changes listed' : 'missing', rail);
      if (chs.length) ok(marks >= 1, 'Edit', 'Changed fields are marked in the form (.lp-cf-ch "Changed", lp-chg, lp-new…)', '≥ 1 marker', marks, main);
      else add('INFO', 'Edit', 'No unsaved changes right now — make one change and run again to check the markers', '', '');
      const was = $$('.lp-cf-was', main).length;
      if ($$('.lp-cf-ch', main).length) ok(was >= 1, 'Edit', 'Changed text fields show "Was …" (.lp-cf-was)', '≥ 1', was, main);
    }

    // ---------- action bar
    const ab = $('.lp-cf-ab', main);
    ok(!!ab, 'Actions', 'Action bar .lp-cf-ab at the end of the main column', 'present', ab ? 'present' : 'missing', main);
    if (ab) {
      ok(cs(ab).position === 'sticky', 'Actions', 'Action bar is sticky', 'sticky', cs(ab).position, ab);
      ok(!!$('.lp-rqn', ab), 'Actions', '"* Required" note at the left', 'present', $('.lp-rqn', ab) ? 'present' : 'missing', ab);
      const bts = $$('button', ab).filter(vis);
      const notLp = bts.filter((b) => !b.classList.contains('lp-btn'));
      ok(notLp.length === 0, 'Actions', 'Every action button is .lp-btn', '0 others', notLp.length + (notLp.length ? ': ' + notLp.map(txt).join(', ') : ''), notLp[0]);
      const prim = bts.filter((b) => b.classList.contains('lp-btn-p'));
      ok(prim.length === 1, 'Actions', 'Exactly one primary (teal) button', 1, prim.length, ab);
      if (prim[0] && !prim[0].matches(':hover') && !prim[0].classList.contains('lp-dis') && !prim[0].disabled) {
        const c = cs(prim[0]);
        ok(c.backgroundColor === C.accent && c.color === C.on, 'Actions', 'Primary "' + txt(prim[0]) + '" is solid teal with dark text', C.accent + ' / ' + C.on, c.backgroundColor + ' / ' + c.color, prim[0]);
        ok(bts[bts.length - 1] === prim[0], 'Actions', 'Primary button is the last (right-most) button', 'last', bts.indexOf(prim[0]) + 1 + ' of ' + bts.length, prim[0]);
      }
      if (edit) ok(!!$('.lp-msg.lp-chg', ab) || !$$('.lp-cf-chr', rail).length, 'Actions', 'Edit: "N unsaved changes" message in the bar (.lp-msg.lp-chg)', 'present', $('.lp-msg.lp-chg', ab) ? txt($('.lp-msg.lp-chg', ab)) : 'missing', ab, true);
    }

    // ---------- per form
    const sec = (i) => secs[i] || null;
    if (form === 'application') {
      ok(!!$('.lp-cf-af', main), 'Application', 'ITAM name is the auto-filled field .lp-cf-af', 'present', $('.lp-cf-af', main) ? txt($('.lp-cf-af', main)) : 'missing');
      ok(!!$('.lp-cf-dz, .lp-cf-fc', main), 'Application', 'OLA drop zone .lp-cf-dz (or file card .lp-cf-fc)', 'present', $('.lp-cf-dz, .lp-cf-fc', main) ? 'present' : 'missing');
      if ($('.lp-cf-dd', main)) { state = 'list open'; ok($$('.lp-cf-dd .lp-opt', main).length >= 1 && !!$('.lp-cf-dd .lp-cf-otag', main), 'Application', 'Open list: rows .lp-opt with the mono ID tag .lp-cf-otag', 'present', $$('.lp-cf-dd .lp-opt', main).length + ' rows'); }
      if ($('.lp-cf-bn', main)) state = 'issues';
    }
    if (form === 'itam') ok($$('.lp-cf-f', sec(0) || main).length >= 5, 'ITAM', 'ITAM details has the 5 fields', '≥ 5', $$('.lp-cf-f', sec(0) || main).length);
    if (form === 'feature' || form === 'action') {
      ok(!!$('.lp-cf-band .lp-scf', main), 'Grid', 'Application band with the big trigger .lp-scf', 'present', $('.lp-cf-band .lp-scf', main) ? 'present' : 'missing');
      const ge = $('.lp-cf-ge', main);
      ok(!!ge, 'Grid', 'Grid editor .lp-cf-ge', 'present', ge ? 'present' : 'missing');
      if (ge) {
        const h = $('.lp-cf-gr.lp-hd', ge);
        ok(!!h && near(h.getBoundingClientRect().height, 40, 1.5) && cs(h).textTransform === 'uppercase', 'Grid', 'Header row 40px, uppercase', '40px uppercase', h ? n(h.getBoundingClientRect().height) + 'px ' + cs(h).textTransform : 'missing', h || ge);
        const rows = $$('.lp-cf-gr:not(.lp-hd)', ge);
        ok(rows.length >= 1, 'Grid', 'At least one row', '≥ 1', rows.length, ge);
        rows.forEach((r, i) => {
          ok($$('.lp-cf-ci', r).length >= 2, 'Grid', 'Row ' + (i + 1) + ': inline inputs .lp-cf-ci for name and description', '2', $$('.lp-cf-ci', r).length, r);
          ok(!!$('.lp-cf-rs', r), 'Grid', 'Row ' + (i + 1) + ': Check cell .lp-cf-rs', 'present', $('.lp-cf-rs', r) ? txt($('.lp-cf-rs', r)) : 'missing', r);
        });
        const ci = $('.lp-cf-ci', ge);
        if (ci) ok(near(ci.getBoundingClientRect().height, 38, 1.5), 'Grid', 'Inline input height', '38px', n(ci.getBoundingClientRect().height) + 'px', ci);
        if (!edit) {
          ok(!!$('.lp-cf-gk', ge), 'Grid', 'Keyboard hint row .lp-cf-gk (Tab / Enter / Ctrl V)', 'present', $('.lp-cf-gk', ge) ? 'present' : 'missing', ge);
          ok($$('.lp-cf-shr .lp-btn-sm', ge).length === 3, 'Grid', 'Header tools: Add row, Paste from Excel, Import CSV', 3, $$('.lp-cf-shr .lp-btn-sm', ge).length, ge);
          const sw = $('.lp-cf-sw input', main);
          ok(!!sw, 'Grid', '"Use a different application per row" switch .lp-cf-sw', 'present', sw ? 'present' : 'missing');
          if (sw && sw.checked) { state = 'per row'; ok(rows.every((r) => $('.lp-cf-gsl', r)), 'Grid', 'Per row on: every row has an application picker .lp-cf-gsl', 'all rows', rows.filter((r) => $('.lp-cf-gsl', r)).length + '/' + rows.length, ge); }
        }
      }
    }
    if (form === 'profile' || form === 'policy') {
      const cond = sec(2);
      ok(!!cond && !!$('.lp-cf-conds, .lp-cf-empty, .lp-cf-cb', cond), 'Conditions', 'Conditions section shows the list .lp-cf-conds, the empty box .lp-cf-empty or the builder .lp-cf-cb', 'present', cond && $('.lp-cf-conds, .lp-cf-empty, .lp-cf-cb', cond) ? 'present' : 'missing', cond);
      const cr = $$('.lp-cf-cr', main);
      if (cr.length) {
        ok(txt($('.lp-cf-lg', cr[0])) === 'WHERE' && cr.slice(1).every((r) => txt($('.lp-cf-lg', r)) === 'AND'), 'Conditions', 'First row WHERE, then AND', 'WHERE, AND…', cr.map((r) => txt($('.lp-cf-lg', r))).join(', '), cr[0]);
        ok(cr.every((r) => $('.lp-op', r)), 'Conditions', 'Each condition has the operator chip .lp-op', 'all', cr.filter((r) => $('.lp-op', r)).length + '/' + cr.length, cr[0]);
      }
      if ($('.lp-cf-cb', main)) state = 'adding a condition';
    }
    if (form === 'policy') {
      ok(!!$('.lp-cf-sw', sec(0) || main), 'Policy', 'Global policy switch .lp-cf-sw in Policy details', 'present', $('.lp-cf-sw', sec(0) || main) ? 'present' : 'missing');
      ok(!!$('.lp-cf-its, .lp-cf-ie, .lp-cf-empty', sec(1) || main), 'Policy', 'Data profiles: attached items .lp-cf-its (or the empty line)', 'present', $('.lp-cf-its, .lp-cf-ie, .lp-cf-empty', sec(1) || main) ? 'present' : 'missing');
    }
    if (form === 'entitlement') {
      ok($$('.lp-cf-dp2 .lp-cf-dpc', main).length === 2, 'Entitlement', 'Data permissions: two cards (policies, profiles)', 2, $$('.lp-cf-dp2 .lp-cf-dpc', main).length);
      const vs = $('.lp-vseg', sec(2) || main);
      ok(!!vs && $$('button', vs).length === 2, 'Entitlement', 'List / Grid preview segmented control .lp-vseg', '2 buttons', vs ? $$('button', vs).length : 'missing');
      ok(!!$('.lp-cf-fl, .lp-cf-mx', main), 'Entitlement', 'Feature list .lp-cf-fl or grid preview .lp-cf-mx', 'present', $('.lp-cf-mx', main) ? 'grid' : ($('.lp-cf-fl', main) ? 'list' : 'missing'));
      if ($('.lp-cf-mx', main)) state = 'grid preview';
      ok(!!$('.lp-cf-band .lp-scf', main), 'Entitlement', 'Application band .lp-cf-band in Feature configuration', 'present', $('.lp-cf-band .lp-scf', main) ? 'present' : 'missing');
    }
    if (form === 'account') {
      ok($$('.lp-cf-cas .lp-sel2', main).length === 3, 'Account', 'Access cascade: ITAM → Application → Entitlement (.lp-cf-cas, 3 × .lp-sel2)', 3, $$('.lp-cf-cas .lp-sel2', main).length);
    }

    // ---------- picker
    const pk = $('.lp-cf-pk');
    if (pk) {
      state = (state ? state + ' · ' : '') + 'picker open';
      ok(!!pk.closest('.lp-root'), 'Picker', 'Picker panel is inside an .lp-root', 'inside', pk.closest('.lp-root') ? 'inside' : 'outside', pk);
      ok(near(pk.getBoundingClientRect().width, 640, 2) || window.innerWidth <= 900, 'Picker', 'Picker width', '640px', n(pk.getBoundingClientRect().width) + 'px', pk);
      ok($$('.lp-cf-pki', pk).length >= 1, 'Picker', 'Rows .lp-cf-pki', '≥ 1', $$('.lp-cf-pki', pk).length, pk);
      ok(!!$('.lp-vseg', pk), 'Picker', 'All / Selected segmented control', 'present', $('.lp-vseg', pk) ? 'present' : 'missing', pk);
      ok(!!$('.lp-cf-pk-f .lp-btn-p', pk), 'Picker', 'Footer with the primary Add button', 'present', $('.lp-cf-pk-f .lp-btn-p', pk) ? txt($('.lp-cf-pk-f .lp-btn-p', pk)) : 'missing', pk);
      ok(!!$('.lp-cf-pks'), 'Picker', 'Blurred scrim .lp-cf-pks behind the panel', 'present', $('.lp-cf-pks') ? 'present' : 'missing');
    }

    // ---------- colour audit: no "ocean blue"
    const hsl = (r, g, b) => { r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let h = 0, s = 0; const l = (mx + mn) / 2; if (mx !== mn) { const d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60; } return [h, s * 100, l * 100]; };
    const isBlue = (str, minA) => {
      const re = /rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?\)/g; let m;
      while ((m = re.exec(str))) {
        const a = m[4] === undefined ? 1 : parseFloat(m[4]); if (a < minA) continue;
        const [h, s, l] = hsl(+m[1], +m[2], +m[3]);
        if (h >= 195 && h <= 235 && s >= 55 && l >= 28 && l <= 70) return m[0];
      }
      return null;
    };
    const blue = [];
    [root].concat($$('*', root)).filter((el) => !el.closest('.lp-aur') && vis(el)).forEach((el) => {
      const s = cs(el);
      const hit = isBlue(s.color, 0.3) || isBlue(s.backgroundColor, 0.25) || isBlue(s.borderTopColor, 0.4) || isBlue(s.borderBottomColor, 0.4) || isBlue(s.backgroundImage, 0.25);
      if (hit) blue.push([el, hit]);
    });
    ok(blue.length === 0, 'Colours', 'No "ocean blue" (#1E88E5 / #2196F3 / #1976D2 family) anywhere — teal tokens only', '0 elements', blue.length + (blue.length ? ' — e.g. ' + blue.slice(0, 5).map((x) => path(x[0]) + ' ' + x[1]).join(' | ') : ''), blue[0] && blue[0][0]);

    return finish();

    function finish() {
      const pass = R.filter((r) => r.status === 'PASS').length, fail = R.filter((r) => r.status === 'FAIL').length, warn = R.filter((r) => r.status === 'WARN').length;
      const head = 'FMCES forms verify v1 — ' + form + ' · ' + mode + (state ? ' · ' + state : '') + ' — ' + pass + ' PASS, ' + fail + ' FAIL, ' + warn + ' WARN';
      try {
        console.log('%c' + head, 'font-weight:700;color:' + (fail ? '#F4A3A3' : '#2DD4BF'));
        console.table(R.filter((r) => r.status !== 'PASS').map((r) => ({ status: r.status, area: r.area, check: r.check, expected: r.expected, actual: r.actual })));
      } catch (e) { /* no console */ }
      if (opts.highlight) R.filter((r) => r.status === 'FAIL' && r.el).forEach((r) => { r.el.style.outline = '2px solid #F4A3A3'; r.el.style.outlineOffset = '2px'; });
      if (opts.overlay) panel(head, fail);
      const res = { form: form, mode: mode, state: state, pass: pass, fail: fail, warn: warn, summary: head,
        problems: R.filter((r) => r.status !== 'PASS').map((r) => r.status + ' [' + r.area + '] ' + r.check + ' — expected: ' + r.expected + ' — actual: ' + r.actual) };
      window.__lpFormVerifyLast = res;
      return res;
    }
    function panel(head, fail) {
      const old = document.getElementById('lp-form-verify-panel'); if (old) old.remove();
      const d = document.createElement('div'); d.id = 'lp-form-verify-panel';
      d.setAttribute('style', 'position:fixed;right:16px;bottom:16px;z-index:2147483647;width:540px;max-height:60vh;overflow:auto;background:#0B141B;color:#E6EEF2;border:2px solid ' + (fail ? '#F4A3A3' : '#2DD4BF') + ';border-radius:12px;padding:12px 14px;font:12px/1.45 ui-monospace,Menlo,Consolas,monospace;box-shadow:0 20px 60px rgba(0,0,0,.6)');
      const rows = R.filter((r) => r.status !== 'PASS').map((r) => '<div style="padding:6px 0;border-top:1px solid #1E3240"><b style="color:' + (r.status === 'FAIL' ? '#F4A3A3' : r.status === 'WARN' ? '#F6C177' : '#93C5FD') + '">' + r.status + '</b> [' + esc(r.area) + '] ' + esc(r.check) + (r.expected ? '<br><span style="color:#86A0AE">expected:</span> ' + esc(r.expected) : '') + (r.actual ? '<br><span style="color:#86A0AE">actual:</span> ' + esc(r.actual) : '') + '</div>').join('');
      d.innerHTML = '<div style="display:flex;gap:8px;align-items:center;margin-bottom:6px"><b style="flex:1;color:' + (fail ? '#F4A3A3' : '#2DD4BF') + '">' + esc(head) + '</b><button type="button" style="font:inherit;background:#1B3140;color:#E6EEF2;border:0;border-radius:6px;padding:3px 8px;cursor:pointer">close</button></div>' + (rows || '<div style="color:#2DD4BF">All checks passed.</div>');
      d.querySelector('button').onclick = () => d.remove();
      document.body.appendChild(d);
    }
    function esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]); }
  }

  window.lpFormVerify = lpFormVerify;
  if (/[?&]lpformverify\b/.test(location.search)) setTimeout(() => lpFormVerify(), 2500);
})();
