# FMCES create & edit pages — component markup

Each block below is copied from a reference page in `reference/` (the file is named under each heading). It is the **final HTML with the final class names**: translate it to your framework, bind your existing state and handlers, and keep the classes, structure and inline custom properties (`--d`, `--i`, `--s`, `--gc`, `--k`, `--c`, `--p`) exactly.

- Text and values in these blocks are **sample data** from the mockup. Use the app's real labels, placeholders and data; keep the app's wording wherever it has its own.
- Icons are inline SVGs (`<svg class="lp-i">` stroke icons; `lp-b` = bold). Copy the `d` paths as they are.
- `.lp-cf-f` takes `style="--s: N"`: N of 12 grid columns (4 = a third, 6 = half, 12 = full width).
- For anything not shown here, open the reference HTML and read its source.

## Page skeleton (every create / edit page)

```html
<div class="lp-root" data-lp-form="application|itam|feature|action|profile|policy|entitlement|account" data-lp-mode="create|edit">
  <div class="lp-pg">
    <div class="lp-aur" aria-hidden="true"><i class="lp-a1"></i><i class="lp-a2"></i></div>
    <div class="lp-pga">
      <!-- Page header (below) -->
      <div class="lp-cf-wrap">
        <div class="lp-cf-main">
          <!-- [Issues banner] -->
          <!-- Section cards (.lp-cf-sc) / grid editor (.lp-cf-ge), in order -->
          <!-- Action bar (.lp-cf-ab) -->
        </div>
        <aside class="lp-cf-rail" aria-label="Form progress">
          <!-- Edit only: Your changes card --> <!-- Progress card --> <!-- Lifecycle card (or Summary / Paste tips) -->
        </aside>
      </div>
    </div>
  </div>
  <!-- Pickers (Select data policies / profiles) render here, inside .lp-root -->
</div>
```

## Page header — Create

Eyebrow: back button, module number (dock order), crumb "FMCES / <module> / New". Title 36/300. Right: status pill (`lp-new` "New", or `lp-draft` "Draft" where the app saves drafts). From `reference/01-application-create.html`.

```html
<header class="lp-ph lp-cf-hd lp-rz" style="--d: 0">
  <span class="lp-bign" aria-hidden="true">01</span>
  <div class="lp-ph-l">
    <p class="lp-eb">
      <button type="button" class="lp-cf-bk" aria-label="Back">
        <svg class="lp-i lp-b" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>
      </button>
      <b>01</b><i></i><span class="lp-cf-crumb">FMCES<s>/</s>App Management<s>/</s><em>New</em></span>
    </p>
    <h1 class="lp-pt">Add application</h1>
    <p class="lp-ps">
      <span>Fill in the application details below.</span>
    </p>
  </div>
  <div class="lp-cf-hr">
    <span class="lp-cf-st lp-draft"><i></i>Draft</span>
  </div>
</header>
```

## Page header — Edit

Same header. Under the title: the record chip `.lp-cf-rec` (monogram, name, status dot + word, version). Right: `lp-draft` pill "Editing V2" and the last-saved line `.lp-cf-sv`. From `reference/01-application-edit.html`.

```html
<header class="lp-ph lp-cf-hd lp-rz" style="--d: 0">
  <span class="lp-bign" aria-hidden="true">01</span>
  <div class="lp-ph-l">
    <p class="lp-eb">
      <button type="button" class="lp-cf-bk" aria-label="Back">
        <svg class="lp-i lp-b" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>
      </button>
      <b>01</b><i></i><span class="lp-cf-crumb">FMCES<s>/</s>App Management<s>/</s><em>Edit</em></span>
    </p>
    <h1 class="lp-pt">Edit application</h1>
    <p class="lp-ps">
      <span class="lp-cf-rec"><span class="lp-mgx">RE</span><b class="lp-mono">RATAN_ENTITLEMENT_RULE</b><span class="lp-lc lp-lc-live"><i></i><span class="lp-lct">Approved</span></span><span class="lp-vr">V2</span></span><span>Update the application details below.</span>
    </p>
  </div>
  <div class="lp-cf-hr">
    <span class="lp-cf-st lp-draft"><i></i>Editing V2</span><span class="lp-cf-sv"><svg class="lp-i lp-b" width="13" height="13" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>Draft saved 2 min ago</span>
  </div>
</header>
```

## Issues banner

Shown above the first section after a submit with errors. Each link scrolls to and focuses the field. From `reference/01-application-create-issues.html`.

```html
<div class="lp-cf-bn lp-rz" style="--d: 1" role="alert">
  <span class="lp-cf-bn-ic"><svg class="lp-i lp-b" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4 2.8 20h18.4zM12 10v4.5M12 17.5v.01"/></svg></span>
  <div>
    <b>2 things to fix before you submit</b>
    <p>
      <button type="button" class="lp-lk2">ITAM ID</button>
      is required, and the
      <button type="button" class="lp-lk2">OLA document</button>
      is missing.
    </p>
  </div>
</div>
```

## Section card — current section

`.lp-cf-sc` + `lp-act` while the user is in it. Step number `.lp-cf-sn` states: (none) todo, `lp-cur`, `lp-done` (check), `lp-bad` ("!"), `lp-op2` (optional, dashed). Right pill `.lp-cf-pl`: plain "3 of 6", `lp-ok`, `lp-op2` "Optional", `lp-bad` "1 issue", `lp-chg` "2 changed". From `reference/02-itam-create.html`.

```html
<section class="lp-cf-sc lp-rz lp-act" style="--d: 1">
  <div class="lp-cf-sh">
    <span class="lp-cf-sn lp-cur">1</span>
    <div class="lp-cf-stt">
      <h2>ITAM details</h2>
      <p>All five fields are needed to onboard an application under this ITAM.</p>
    </div>
    <div class="lp-cf-shr">
      <span class="lp-cf-pl">2 of 5</span>
    </div>
  </div>
  <div class="lp-cf-sb">
    <div class="lp-cf-g">
      <div class="lp-cf-f" style="--s: 6">
        <span class="lp-cf-l">ITAM name<span class="lp-cf-rq">*</span></span>
        <input class="lp-cf-in lp-mono" type="text" value="STAMP_REFERENCE" placeholder="e.g. STAMP_REFERENCE">
      </div>
      <div class="lp-cf-f" style="--s: 6">
        <span class="lp-cf-l">ITAM ID<span class="lp-cf-rq">*</span></span>
        <input class="lp-cf-in lp-mono" type="text" value="55620" placeholder="e.g. 55620">
        <span class="lp-cf-h">The ID from the ITAM register.</span>
      </div>
      <div class="lp-cf-f" style="--s: 6">
        <span class="lp-cf-l">SNOW group<span class="lp-cf-rq">*</span></span>
        <input class="lp-cf-in lp-mono lp-fo" type="text" value="" placeholder="e.g. FM-CES-L2-SUPPORT">
        <span class="lp-cf-h">The ServiceNow assignment group that supports this application.</span>
      </div>
      <div class="lp-cf-f" style="--s: 6">
        <span class="lp-cf-l">Support DL<span class="lp-cf-rq">*</span></span>
        <input class="lp-cf-in lp-mono" type="text" value="" placeholder="e.g. DL-FMCES-L2-SUPPORT">
      </div>
      <div class="lp-cf-f" style="--s: 12">
        <span class="lp-cf-l">Description<span class="lp-cf-rq">*</span></span><span class="lp-cf-x">
        <textarea class="lp-cf-in lp-cf-ta" placeholder="What is this ITAM entry for?">
        </textarea>
        <span class="lp-cf-cnt">0 / 500</span></span>
      </div>
    </div>
  </div>
</section>
```

## Section card — optional, two fields

Optional fields carry the `.lp-cf-op` "Optional" tag after the label. From `reference/01-application-create.html`.

```html
<section class="lp-cf-sc lp-rz" style="--d: 2">
  <div class="lp-cf-sh">
    <span class="lp-cf-sn lp-op2">2</span>
    <div class="lp-cf-stt">
      <h2>Change &amp; onboarding</h2>
      <p>Change request and go-live details.</p>
    </div>
    <div class="lp-cf-shr">
      <span class="lp-cf-pl lp-op2">Optional</span>
    </div>
  </div>
  <div class="lp-cf-sb">
    <div class="lp-cf-g">
      <div class="lp-cf-f" style="--s: 6">
        <span class="lp-cf-l">CR number<span class="lp-cf-op">Optional</span></span>
        <input class="lp-cf-in lp-mono" type="text" value="" placeholder="e.g. CR12345">
      </div>
      <div class="lp-cf-f" style="--s: 6">
        <span class="lp-cf-l">FMCES onboard date<span class="lp-cf-op">Optional</span></span><span class="lp-cf-x"><span class="lp-cf-ic lp-l"><svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16v14H4zM4 10h16M8 3v5M16 3v5"/></svg></span>
        <input class="lp-cf-in lp-pl" type="text" value="" placeholder="mm/dd/yyyy">
        </span>
      </div>
    </div>
  </div>
</section>
```

## Field — changed (Edit)

Edit only: `.lp-cf-ch` "Changed" at the right of the label, the control gets `lp-chg` (amber border), and `.lp-cf-was` shows the approved value struck through. From `reference/01-application-edit.html`.

```html
<div class="lp-cf-f" style="--s: 6">
  <span class="lp-cf-l">App owner<span class="lp-cf-rq">*</span><span class="lp-cf-ch">Changed</span></span>
  <input class="lp-cf-in lp-mono lp-chg" type="text" value="2023504" placeholder="Bank ID, e.g. 1466717">
  <span class="lp-cf-was">Was <s>1466717</s></span>
</div>
```

## Field — invalid

Control gets `lp-inv`; the message `.lp-cf-e` replaces the hint. From `reference/01-application-create-issues.html`.

```html
<div class="lp-cf-f" style="--s: 4">
  <span class="lp-cf-l">ITAM ID<span class="lp-cf-rq">*</span></span><span class="lp-cf-x">
  <button type="button" class="lp-cf-sl lp-inv" aria-haspopup="listbox" aria-expanded="false">
    <svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></svg><span class="lp-v lp-phd">Search ITAM ID or name</span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
  </button>
  </span><span class="lp-cf-e"><svg class="lp-i lp-b" width="13" height="13" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4 2.8 20h18.4zM12 10v4.5M12 17.5v.01"/></svg>Pick the ITAM this application belongs to</span>
</div>
```

## Select with list open

Trigger `.lp-cf-sl` (`lp-on` while open) + list `.lp-cf-dd` (search `.lp-psr`, rows `.lp-opt` with the mono ID tag `.lp-cf-otag`, keyboard hint). From `reference/01-application-create-itam-open.html`.

```html
<div class="lp-cf-f" style="--s: 4">
  <span class="lp-cf-l">ITAM ID<span class="lp-cf-rq">*</span></span><span class="lp-cf-x">
  <button type="button" class="lp-cf-sl lp-on" aria-haspopup="listbox" aria-expanded="true">
    <svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></svg><span class="lp-v lp-phd">Search ITAM ID or name</span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
  </button>
  <div class="lp-cf-dd" role="listbox">
    <label class="lp-psr">
      <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4"/></svg>
      <input type="search" value="" placeholder="Search by ID or name">
    </label>
    <div class="lp-cf-dd-l">
      <button type="button" class="lp-opt" role="option" aria-selected="false" style="--i: 0">
        <span class="lp-cf-otag">55508</span><span class="lp-grow"><b>FMCES</b><small>DL-FMCES-L2-SUPPORT</small></span>
      </button>
      <button type="button" class="lp-opt" role="option" aria-selected="false" style="--i: 1">
        <span class="lp-cf-otag">50718</span><span class="lp-grow"><b>DMR</b><small>DL-DMR-SUPPORT</small></span>
      </button>
      <button type="button" class="lp-opt" role="option" aria-selected="false" style="--i: 2">
        <span class="lp-cf-otag">19801</span><span class="lp-grow"><b>ITAM-Ent</b><small>DL-ITAM-ENT</small></span>
      </button>
      <button type="button" class="lp-opt" role="option" aria-selected="false" style="--i: 3">
        <span class="lp-cf-otag">50665</span><span class="lp-grow"><b>BLADE</b><small>DL-BLADE-OPS</small></span>
      </button>
      <button type="button" class="lp-opt" role="option" aria-selected="false" style="--i: 4">
        <span class="lp-cf-otag">19959</span><span class="lp-grow"><b>ITAM Versioning V4 Approved</b><small>DL-FMCES-L2-SUPPORT</small></span>
      </button>
      <button type="button" class="lp-opt" role="option" aria-selected="false" style="--i: 5">
        <span class="lp-cf-otag">51358</span><span class="lp-grow"><b>RATAN</b><small>DL-RATAN-ENT-DEV</small></span>
      </button>
      <button type="button" class="lp-opt" role="option" aria-selected="false" style="--i: 6">
        <span class="lp-cf-otag">41190</span><span class="lp-grow"><b>FM-MIS</b><small>DL-FMMIS-SUPPORT</small></span>
      </button>
      <button type="button" class="lp-opt" role="option" aria-selected="false" style="--i: 7">
        <span class="lp-cf-otag">55619</span><span class="lp-grow"><b>STAMP</b><small>DL-STAMP-SUPPORT</small></span>
      </button>
      <button type="button" class="lp-opt" role="option" aria-selected="false" style="--i: 8">
        <span class="lp-cf-otag">51024</span><span class="lp-grow"><b>SAWFL</b><small>DL-SAWFL-SUPPORT</small></span>
      </button>
    </div>
    <div class="lp-cf-dd-f">
      <kbd>↑</kbd><kbd>↓</kbd> move <span style="color: var(--btn)">·</span> <kbd>Enter</kbd> pick <span style="color: var(--btn)">·</span> <kbd>Esc</kbd> close
    </div>
  </div>
  </span>
</div>
```

## Auto-filled field

Read-only value filled from another field (ITAM name from ITAM ID). Empty state: `lp-empty` "Select ITAM ID first". From `reference/01-application-create.html`.

```html
<div class="lp-cf-f" style="--s: 4">
  <span class="lp-cf-l">ITAM name<span class="lp-cf-rq">*</span></span>
  <div class="lp-cf-af">
    <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 11h12v10H6zM8 11V7a4 4 0 0 1 8 0v4"/></svg><span>FMCES</span><em>Auto-filled</em>
  </div>
</div>
```

## Drop zone (no file)

From `reference/01-application-create.html`.

```html
<button type="button" class="lp-cf-dz">
  <span class="lp-cf-dz-ic"><svg class="lp-i" width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 16V5M7 10l5-5 5 5M5 20h14"/></svg></span><span><b>Drop the OLA here, or <u>browse</u></b><small>PDF, Word or text document · up to 10 MB</small></span><span class="lp-fts" aria-hidden="true"><span class="lp-ft lp-pdf">PDF</span><span class="lp-ft lp-doc">DOC</span><span class="lp-ft lp-txt">TXT</span></span>
</button>
```

## File card (file chosen)

From `reference/01-application-edit.html`.

```html
<div class="lp-cf-fc">
  <span class="lp-ft lp-pdf">PDF</span>
  <div class="lp-grow">
    <b>RATAN_OLA_signed_v2.pdf</b><small>412 KB · uploaded 24 Sep 2026 by 2023504</small>
  </div>
  <button type="button" class="lp-btn lp-btn-g lp-btn-sm">
    <svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 16V5M7 10l5-5 5 5M5 20h14"/></svg>Replace
  </button>
  <button type="button" class="lp-cf-xb" aria-label="Remove file">
    <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>
  </button>
</div>
```

## Switch

From `reference/06-policy-create.html`.

```html
<label class="lp-cf-sw">
  <input type="checkbox">
  <span class="lp-k"></span><span><b>Apply this policy globally</b></span>
</label>
```

## Application band (Features / Actions / Entitlement)

Same look as the application band on the Features list page. From `reference/03-feature-create.html`.

```html
<div class="lp-cf-band">
  <div class="lp-scx-f">
    <span class="lp-cf-l">Application<span class="lp-cf-rq">*</span></span>
    <button type="button" class="lp-scf" aria-haspopup="dialog">
      <span class="lp-mgx">SA</span><span class="lp-bt"><b>SAWFL</b><small>ITAM 51024 · 10 features · 52 actions</small></span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
    </button>
  </div>
  <div class="lp-scx-m">
    <span class="lp-kv3"><small>ITAM</small><b>51024</b></span><span class="lp-kv3"><small>Features</small><b>10</b></span><span class="lp-kv3"><small>Status</small><span class="lp-lc lp-lc-live"><i></i><span class="lp-lct">Approved</span></span></span>
  </div>
</div>
```

## Grid editor — Features to add (one application)

Header row `.lp-cf-gr.lp-hd`; rows `.lp-cf-gr` (+ `lp-warn` duplicate, `lp-bad` invalid, `lp-chgr` changed); inline inputs `.lp-cf-ci` (`lp-fo` focused, `lp-inv` invalid); Check column `.lp-cf-rs` (`lp-ok` Ready, `lp-warn`, `lp-bad`, `lp-new` New row, `lp-chg` Changed); keyboard hint `.lp-cf-gk`. `--gc` = column template. From `reference/03-feature-create.html`.

```html
<section class="lp-cf-ge lp-rz" style="--d: 2">
  <div class="lp-cf-sh" style="padding-bottom: 16px">
    <span class="lp-cf-sn lp-cur">2</span>
    <div class="lp-cf-stt">
      <h2>Features to add</h2>
      <p>One row per feature. Type, or paste straight from Excel.</p>
    </div>
    <div class="lp-cf-shr">
      <button type="button" class="lp-btn lp-btn-g lp-btn-sm">
        <svg class="lp-i lp-b" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>Add row
      </button>
      <button type="button" class="lp-btn lp-btn-g lp-btn-sm">
        <svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 4h8v4H8zM6 6H5v15h14V6h-1M9 12h6M9 16h6"/></svg>Paste from Excel
      </button>
      <button type="button" class="lp-btn lp-btn-g lp-btn-sm">
        <svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 16V5M7 10l5-5 5 5M5 20h14"/></svg>Import CSV
      </button>
      <span class="lp-cf-pl">3 rows</span>
    </div>
  </div>
  <div class="lp-cf-gt" role="table">
    <div class="lp-cf-gr lp-hd" style="--gc: 48px minmax(0,1fr) minmax(0,1.6fr) 200px 44px">
      <span>#</span><span>Feature name <b class="lp-cf-rq">*</b></span><span>Description <b class="lp-cf-rq">*</b></span><span>Check</span><span></span>
    </div>
    <div class="lp-cf-gr" style="--gc: 48px minmax(0,1fr) minmax(0,1.6fr) 200px 44px; --i: 0">
      <span class="lp-ix">1</span>
      <input class="lp-cf-ci" type="text" value="Trade Booking" placeholder="Type a name…">
      <input class="lp-cf-ci lp-d" type="text" value="Book and amend FX trades for the desk" placeholder="…and a description">
      <span class="lp-cf-rs lp-ok" style="--i: 0"><i></i>Ready</span>
      <button type="button" class="lp-cf-xb" aria-label="Remove row 1">
        <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
      </button>
    </div>
    <div class="lp-cf-gr" style="--gc: 48px minmax(0,1fr) minmax(0,1.6fr) 200px 44px; --i: 1">
      <span class="lp-ix">2</span>
      <input class="lp-cf-ci" type="text" value="Position Viewer" placeholder="Type a name…">
      <input class="lp-cf-ci lp-d" type="text" value="Read-only view of open positions" placeholder="…and a description">
      <span class="lp-cf-rs lp-ok" style="--i: 1"><i></i>Ready</span>
      <button type="button" class="lp-cf-xb" aria-label="Remove row 2">
        <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
      </button>
    </div>
    <div class="lp-cf-gr lp-warn" style="--gc: 48px minmax(0,1fr) minmax(0,1.6fr) 200px 44px; --i: 2">
      <span class="lp-ix">3</span>
      <input class="lp-cf-ci" type="text" value="Data Policy" placeholder="Type a name…">
      <input class="lp-cf-ci lp-d" type="text" value="Create and approve data policies" placeholder="…and a description">
      <span class="lp-cf-rs lp-warn" style="--i: 2"><i></i>Already in SAWFL</span>
      <button type="button" class="lp-cf-xb" aria-label="Remove row 3">
        <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
      </button>
    </div>
    <div class="lp-cf-gr" style="--gc: 48px minmax(0,1fr) minmax(0,1.6fr) 200px 44px; --i: 3">
      <span class="lp-ix">4</span>
      <input class="lp-cf-ci lp-fo" type="text" value="" placeholder="Type a name…">
      <input class="lp-cf-ci lp-d" type="text" value="" placeholder="…and a description">
      <span class="lp-cf-rs lp-new" style="--i: 3"><i></i>New row</span>
      <button type="button" class="lp-cf-xb" aria-label="Remove row 4">
        <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
      </button>
    </div>
  </div>
  <div class="lp-cf-gk">
    <kbd>Tab</kbd> next cell <span class="lp-dot"></span><kbd>Enter</kbd> next row <span class="lp-dot"></span><kbd>Ctrl</kbd><kbd>V</kbd> paste rows from Excel: name in column 1, description in column 2
  </div>
</section>
```

## Grid editor — a different application per row (Actions)

Extra Application column with the per-row picker `.lp-cf-gsl`. From `reference/04-action-create-per-row.html`.

```html
<section class="lp-cf-ge lp-rz" style="--d: 2">
  <div class="lp-cf-sh" style="padding-bottom: 16px">
    <span class="lp-cf-sn lp-cur">2</span>
    <div class="lp-cf-stt">
      <h2>Actions to add</h2>
      <p>One row per action. Type, or paste straight from Excel.</p>
    </div>
    <div class="lp-cf-shr">
      <button type="button" class="lp-btn lp-btn-g lp-btn-sm">
        <svg class="lp-i lp-b" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>Add row
      </button>
      <button type="button" class="lp-btn lp-btn-g lp-btn-sm">
        <svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 4h8v4H8zM6 6H5v15h14V6h-1M9 12h6M9 16h6"/></svg>Paste from Excel
      </button>
      <button type="button" class="lp-btn lp-btn-g lp-btn-sm">
        <svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 16V5M7 10l5-5 5 5M5 20h14"/></svg>Import CSV
      </button>
      <span class="lp-cf-pl">3 rows</span>
    </div>
  </div>
  <div class="lp-cf-gt" role="table">
    <div class="lp-cf-gr lp-hd" style="--gc: 48px minmax(0,0.9fr) minmax(0,1fr) minmax(0,1.5fr) 200px 44px">
      <span>#</span><span>Application <b class="lp-cf-rq">*</b></span><span>Action name <b class="lp-cf-rq">*</b></span><span>Description <b class="lp-cf-rq">*</b></span><span>Check</span><span></span>
    </div>
    <div class="lp-cf-gr" style="--gc: 48px minmax(0,0.9fr) minmax(0,1fr) minmax(0,1.5fr) 200px 44px; --i: 0">
      <span class="lp-ix">1</span>
      <button type="button" class="lp-cf-gsl">
        <span class="lp-mgx">FM</span>FMCES<svg class="lp-i lp-b lp-chev" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
      </button>
      <input class="lp-cf-ci" type="text" value="Re-evaluate" placeholder="Type a name…">
      <input class="lp-cf-ci lp-d" type="text" value="Re-run the entitlement rules for an application" placeholder="…and a description">
      <span class="lp-cf-rs lp-ok" style="--i: 0"><i></i>Ready</span>
      <button type="button" class="lp-cf-xb" aria-label="Remove row 1">
        <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
      </button>
    </div>
    <div class="lp-cf-gr" style="--gc: 48px minmax(0,0.9fr) minmax(0,1fr) minmax(0,1.5fr) 200px 44px; --i: 1">
      <span class="lp-ix">2</span>
      <button type="button" class="lp-cf-gsl">
        <span class="lp-mgx">SA</span>SAWFL<svg class="lp-i lp-b lp-chev" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
      </button>
      <input class="lp-cf-ci" type="text" value="Bulk Upload" placeholder="Type a name…">
      <input class="lp-cf-ci lp-d" type="text" value="Upload entitlements from an Excel file" placeholder="…and a description">
      <span class="lp-cf-rs lp-ok" style="--i: 1"><i></i>Ready</span>
      <button type="button" class="lp-cf-xb" aria-label="Remove row 2">
        <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
      </button>
    </div>
    <div class="lp-cf-gr lp-bad" style="--gc: 48px minmax(0,0.9fr) minmax(0,1fr) minmax(0,1.5fr) 200px 44px; --i: 2">
      <span class="lp-ix">3</span>
      <button type="button" class="lp-cf-gsl">
        <span class="lp-mgx">RA</span>RATAN<svg class="lp-i lp-b lp-chev" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
      </button>
      <input class="lp-cf-ci" type="text" value="Approve" placeholder="Type a name…">
      <input class="lp-cf-ci lp-d lp-fo lp-inv" type="text" value="" placeholder="…and a description">
      <span class="lp-cf-rs lp-bad" style="--i: 2"><i></i>Description needed</span>
      <button type="button" class="lp-cf-xb" aria-label="Remove row 3">
        <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
      </button>
    </div>
    <div class="lp-cf-gr" style="--gc: 48px minmax(0,0.9fr) minmax(0,1fr) minmax(0,1.5fr) 200px 44px; --i: 3">
      <span class="lp-ix">4</span>
      <button type="button" class="lp-cf-gsl lp-phd">
        Pick…<svg class="lp-i lp-b lp-chev" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
      </button>
      <input class="lp-cf-ci" type="text" value="" placeholder="Type a name…">
      <input class="lp-cf-ci lp-d" type="text" value="" placeholder="…and a description">
      <span class="lp-cf-rs lp-new" style="--i: 3"><i></i>New row</span>
      <button type="button" class="lp-cf-xb" aria-label="Remove row 4">
        <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
      </button>
    </div>
  </div>
  <div class="lp-cf-gk">
    <kbd>Tab</kbd> next cell <span class="lp-dot"></span><kbd>Enter</kbd> next row <span class="lp-dot"></span><kbd>Ctrl</kbd><kbd>V</kbd> paste rows from Excel: name in column 1, description in column 2
  </div>
</section>
```

## Conditions — empty

From `reference/05-profile-create.html`.

```html
<div class="lp-cf-empty">
  <span class="lp-cf-empty-ic"><svg class="lp-i" width="17" height="17" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16l-6 8v6l-4-2v-4z"/></svg></span><span><b>No conditions added yet</b>Add at least one. Rows show only when every condition matches.</span>
</div>
```

## Conditions — list

First row `WHERE`, next rows `AND` (`.lp-cf-lg.lp-w` / `.lp-cf-lg.lp-a`). Operator chip `.lp-op`; values `.lp-vc` (`<em>` = code). Edit: a row added in this edit gets `lp-new`. From `reference/05-profile-edit.html`.

```html
<div class="lp-cf-conds">
  <div class="lp-cf-cr" style="--i: 0">
    <span class="lp-cf-lg lp-w">WHERE</span><span class="lp-k">Booking_Location<small>Booking location</small></span><span class="lp-op">IN</span><span class="lp-vcs"><span class="lp-vc"><em>SG</em>Singapore</span><span class="lp-vc"><em>HK</em>Hong Kong</span></span>
    <button type="button" class="lp-cf-xb" aria-label="Remove condition">
      <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
    </button>
  </div>
  <div class="lp-cf-cr lp-new" style="--i: 1">
    <span class="lp-cf-lg lp-a">AND</span><span class="lp-k">Product_Type<small style="color: var(--draft); font-weight: 700">Added in this edit</small></span><span class="lp-op">NOT IN</span><span class="lp-vcs"><span class="lp-vc lp-pl">FX_SPOT</span></span>
    <button type="button" class="lp-cf-xb" aria-label="Remove condition">
      <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
    </button>
  </div>
</div>
```

## Conditions — adding one

The inline "New condition" box `.lp-cf-cb`. From `reference/06-policy-create.html`.

```html
<div class="lp-cf-cb">
  <p class="lp-cf-cb-t">
    <svg class="lp-i lp-b" width="13" height="13" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16l-6 8v6l-4-2v-4z"/></svg>New condition
  </p>
  <div class="lp-cf-f" style="--s: 4">
    <span class="lp-cf-l">Key<span class="lp-cf-rq">*</span></span><span class="lp-cf-x">
    <button type="button" class="lp-cf-sl" aria-haspopup="listbox" aria-expanded="false">
      <span class="lp-v lp-mono">Booking_Location</span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
    </button>
    </span>
  </div>
  <div class="lp-cf-f" style="--s: 4">
    <span class="lp-cf-l">Operator<span class="lp-cf-rq">*</span></span><span class="lp-cf-x">
    <button type="button" class="lp-cf-sl" aria-haspopup="listbox" aria-expanded="false">
      <span class="lp-v lp-mono">IN</span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
    </button>
    </span>
  </div>
  <div class="lp-cf-f" style="--s: 4">
    <span class="lp-cf-l">Value<span class="lp-cf-rq">*</span></span><span class="lp-cf-x">
    <button type="button" class="lp-cf-sl lp-on" aria-haspopup="listbox">
      <span class="lp-v"><span class="lp-chs"><span class="lp-vc"><em>SG</em>Singapore</span><span class="lp-vc"><em>HK</em>Hong Kong</span></span></span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
    </button>
    </span>
  </div>
  <button type="button" class="lp-btn lp-btn-p">
    <svg class="lp-i lp-b" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>Add
  </button>
  <button type="button" class="lp-btn lp-btn-q">Cancel</button>
</div>
```

## Attached items (data profiles on a policy)

Edit: an item added in this edit gets `lp-new`. From `reference/06-policy-create.html`.

```html
<div class="lp-cf-its">
  <div class="lp-cf-it" style="--i: 0">
    <span class="lp-mgx">SI</span>
    <div class="lp-grow">
      <b>Singapore</b><small>#102 · Booking_Location IN SG</small>
    </div>
    <span class="lp-own">2021102</span>
    <button type="button" class="lp-cf-xb" aria-label="Remove Singapore">
      <svg class="lp-i" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>
    </button>
  </div>
  <div class="lp-cf-it" style="--i: 1">
    <span class="lp-mgx">PE</span>
    <div class="lp-grow">
      <b>Profile-Ent</b><small>#71 · Booking_Location IN SG, HK</small>
    </div>
    <span class="lp-own">2023504</span>
    <button type="button" class="lp-cf-xb" aria-label="Remove Profile-Ent">
      <svg class="lp-i" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>
    </button>
  </div>
</div>
```

## Data permissions (entitlement)

Two cards `.lp-cf-dpc`; empty state `.lp-cf-ie`. From `reference/07-entitlement-create.html`.

```html
<div class="lp-cf-dp2">
  <div class="lp-cf-dpc">
    <div class="lp-cf-dpc-h">
      <span class="lp-cf-dpi"><svg class="lp-i" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/></svg></span>
      <div>
        <b>Data policies<em>1</em><span class="lp-cf-op">Optional</span></b>
      </div>
      <button type="button" class="lp-btn lp-btn-g lp-btn-sm">
        <svg class="lp-i lp-b" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>Add policy
      </button>
    </div>
    <div class="lp-cf-its">
      <div class="lp-cf-it" style="--i: 0">
        <span class="lp-mgx">RO</span>
        <div class="lp-grow">
          <b>RATAN - OM Onshore User</b><small>#192 · Desk IN OM Onshore</small>
        </div>
        <span class="lp-own">2021102</span>
        <button type="button" class="lp-cf-xb" aria-label="Remove RATAN - OM Onshore User">
          <svg class="lp-i" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>
        </button>
      </div>
    </div>
  </div>
  <div class="lp-cf-dpc">
    <div class="lp-cf-dpc-h">
      <span class="lp-cf-dpi"><svg class="lp-i" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 3 7.5l9 4.5 9-4.5zM3 12l9 4.5 9-4.5M3 16.5 12 21l9-4.5"/></svg></span>
      <div>
        <b>Data profiles<em>0</em><span class="lp-cf-op">Optional</span></b>
      </div>
      <button type="button" class="lp-btn lp-btn-g lp-btn-sm">
        <svg class="lp-i lp-b" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>Add profile
      </button>
    </div>
    <div class="lp-cf-ie">
      <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 3 7.5l9 4.5 9-4.5zM3 12l9 4.5 9-4.5M3 16.5 12 21l9-4.5"/></svg>No data profiles attached
    </div>
  </div>
</div>
```

## Feature configuration — controls

Application band, Privileged switch, List / Grid preview `.lp-vseg`, Add feature. From `reference/07-entitlement-create.html`.

```html
<section class="lp-cf-sc lp-rz lp-act" style="--d: 3">
  <div class="lp-cf-sh">
    <span class="lp-cf-sn lp-cur">3</span>
    <div class="lp-cf-stt">
      <h2>Feature configuration</h2>
      <p>Pick the application, then what this entitlement can do in each feature.</p>
    </div>
    <div class="lp-cf-shr">
      <span class="lp-cf-pl">3 features · 6 actions</span>
    </div>
  </div>
  <div class="lp-cf-sb">
    <div class="lp-cf-fcb">
      <div class="lp-cf-band">
        <div class="lp-scx-f">
          <span class="lp-cf-l">Application<span class="lp-cf-rq">*</span></span>
          <button type="button" class="lp-scf" aria-haspopup="dialog">
            <span class="lp-mgx">FM</span><span class="lp-bt"><b>FMCES</b><small>ITAM 55508 · 10 features · 6 actions</small></span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
          </button>
        </div>
        <div class="lp-scx-m">
          <span class="lp-kv3"><small>ITAM</small><b>55508</b></span><span class="lp-kv3"><small>Status</small><span class="lp-lc lp-lc-live"><i></i><span class="lp-lct">Approved</span></span></span>
        </div>
      </div>
    </div>
    <div class="lp-cf-fcb" style="margin-top: 16px">
      <div class="lp-cf-f" style="--s: 3">
        <span class="lp-cf-l">Privileged<span class="lp-cf-op">Optional</span></span>
        <label class="lp-cf-sw">
          <input type="checkbox">
          <span class="lp-k"></span><span><b>No</b><small>Grants elevated access</small></span>
        </label>
      </div>
      <span class="lp-grow2"></span>
      <div class="lp-vseg" role="tablist" aria-label="View">
        <span class="lp-ind" style="transform: translateX(0%)"></span>
        <button type="button" role="tab" class="lp-on">
          <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/></svg>List
        </button>
        <button type="button" role="tab" class="">
          <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h16v16H4zM4 10h16M4 15h16M10 4v16M15 4v16"/></svg>Grid preview
        </button>
      </div>
      <button type="button" class="lp-btn lp-btn-g">
        <svg class="lp-i lp-b" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>Add feature
      </button>
    </div>
    <div class="lp-cf-fl">
      <div class="lp-cf-flr lp-hd">
        <span>Feature</span><span>Actions</span><span>Privileged</span><span></span>
      </div>
      <div class="lp-cf-flr" style="--i: 0">
        <span class="lp-fn"><span class="lp-mgx">DP</span>Data Policy</span><span class="lp-acts"><span class="lp-acp"><svg class="lp-i lp-b" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>View</span><span class="lp-acp"><svg class="lp-i lp-b" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>Approve</span></span><span><span class="lp-yn">No</span></span>
        <button type="button" class="lp-cf-xb" aria-label="Remove Data Policy">
          <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
        </button>
      </div>
      <div class="lp-cf-flr" style="--i: 1">
        <span class="lp-fn"><span class="lp-mgx">DP</span>Data Profile</span><span class="lp-acts"><span class="lp-acp"><svg class="lp-i lp-b" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>View</span><span class="lp-acp"><svg class="lp-i lp-b" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>Approve</span></span><span><span class="lp-yn">No</span></span>
        <button type="button" class="lp-cf-xb" aria-label="Remove Data Profile">
          <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
        </button>
      </div>
      <div class="lp-cf-flr" style="--i: 2">
        <span class="lp-fn"><span class="lp-mgx">RE</span>Reports</span><span class="lp-acts"><span class="lp-acp"><svg class="lp-i lp-b" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>View</span><span class="lp-acp"><svg class="lp-i lp-b" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>Download</span></span><span><span class="lp-yn">No</span></span>
        <button type="button" class="lp-cf-xb" aria-label="Remove Reports">
          <svg class="lp-i" width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
        </button>
      </div>
    </div>
    <div class="lp-cf-cb" style="grid-template-columns: minmax(0,1fr) minmax(0,1.4fr) auto auto auto">
      <p class="lp-cf-cb-t">
        <svg class="lp-i lp-b" width="13" height="13" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>Add a feature
      </p>
      <div class="lp-cf-f" style="--s: 4">
        <span class="lp-cf-l">Feature<span class="lp-cf-rq">*</span></span><span class="lp-cf-x">
        <button type="button" class="lp-cf-sl" aria-haspopup="listbox" aria-expanded="false">
          <span class="lp-mgx">IR</span><span class="lp-v">IAM Reports</span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
        </button>
        </span>
      </div>
      <div class="lp-cf-f">
        <span class="lp-cf-l">Actions<span class="lp-cf-rq">*</span></span>
        <div class="lp-acts" style="display:flex;gap:6px;flex-wrap:wrap;min-height:44px;align-items:center">
          <button type="button" class="lp-acp" aria-pressed="true">
            <svg class="lp-i lp-b" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>View
          </button>
          <button type="button" class="lp-acp lp-off" aria-pressed="false">
            <svg class="lp-i lp-b" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>Download
          </button>
        </div>
      </div>
      <div class="lp-cf-f">
        <span class="lp-cf-l">Privileged</span>
        <label class="lp-cf-sw">
          <input type="checkbox">
          <span class="lp-k"></span><span><b>No</b></span>
        </label>
      </div>
      <button type="button" class="lp-btn lp-btn-p">
        <svg class="lp-i lp-b" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>Add
      </button>
      <button type="button" class="lp-btn lp-btn-q">Cancel</button>
    </div>
  </div>
</section>
```

## Feature configuration — grid preview

`.lp-cf-mxc` cells: `lp-on` granted, `lp-avl` available, `lp-na` not available, `lp-chg` changed in this edit. From `reference/07-entitlement-edit-grid.html`.

```html
<div class="lp-cf-mx">
  <div class="lp-cf-mxr lp-hd">
    <span>Feature</span><span>View</span><span>Edit</span><span>Approve</span><span>Download</span><span>Upload</span><span>Delete</span>
  </div>
  <div class="lp-cf-mxr">
    <span class="lp-fn"><span class="lp-mgx">AP</span>Application</span><span class="lp-cf-mxc lp-on" style="--i: 0" aria-label="View: granted"><svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span class="lp-cf-mxc lp-on" style="--i: 1" aria-label="Edit: granted"><svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span class="lp-cf-mxc lp-on" style="--i: 2" aria-label="Approve: granted"><svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span><span class="lp-cf-mxc lp-avl" aria-label="Delete: not granted"></span>
  </div>
  <div class="lp-cf-mxr">
    <span class="lp-fn"><span class="lp-mgx">UE</span>User Entitlement</span><span class="lp-cf-mxc lp-on" style="--i: 3" aria-label="View: granted"><svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span class="lp-cf-mxc lp-on" style="--i: 4" aria-label="Edit: granted"><svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span class="lp-cf-mxc lp-avl" aria-label="Approve: not granted"></span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span><span class="lp-cf-mxc lp-chg" aria-label="Upload: granted (changed)"><svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span class="lp-cf-mxc lp-avl" aria-label="Delete: not granted"></span>
  </div>
  <div class="lp-cf-mxr">
    <span class="lp-fn"><span class="lp-mgx">EN</span>Entitlement</span><span class="lp-cf-mxc lp-on" style="--i: 5" aria-label="View: granted"><svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span class="lp-cf-mxc lp-on" style="--i: 6" aria-label="Edit: granted"><svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span class="lp-cf-mxc lp-avl" aria-label="Approve: not granted"></span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span><span class="lp-cf-mxc lp-avl" aria-label="Delete: not granted"></span>
  </div>
  <div class="lp-cf-mxr">
    <span class="lp-fn"><span class="lp-mgx">DP</span>Data Profile</span><span class="lp-cf-mxc lp-on" style="--i: 7" aria-label="View: granted"><svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span class="lp-cf-mxc lp-avl" aria-label="Edit: not granted"></span><span class="lp-cf-mxc lp-avl" aria-label="Approve: not granted"></span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span><span class="lp-cf-mxc lp-avl" aria-label="Delete: not granted"></span>
  </div>
  <div class="lp-cf-mxr">
    <span class="lp-fn"><span class="lp-mgx">DP</span>Data Policy</span><span class="lp-cf-mxc lp-on" style="--i: 8" aria-label="View: granted"><svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span class="lp-cf-mxc lp-avl" aria-label="Edit: not granted"></span><span class="lp-cf-mxc lp-avl" aria-label="Approve: not granted"></span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span><span class="lp-cf-mxc lp-avl" aria-label="Delete: not granted"></span>
  </div>
  <div class="lp-cf-mxr">
    <span class="lp-fn"><span class="lp-mgx">AP</span>API</span><span class="lp-cf-mxc lp-on" style="--i: 9" aria-label="View: granted"><svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span class="lp-cf-mxc lp-avl" aria-label="Edit: not granted"></span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span><span class="lp-cf-mxc lp-na" aria-label="Not available">–</span>
  </div>
</div>
```

## Cascade (Create account)

ITAM → Application → Entitlement, the same big selects as the Entitlement Users finder. From `reference/08-account-create.html`.

```html
<div class="lp-cf-cas">
  <div class="lp-cf-cs">
    <button type="button" class="lp-sel2" aria-haspopup="listbox">
      <span class="lp-sel2-n lp-ok"><svg class="lp-i lp-b" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span><small>ITAM</small><b class="">55508 · FMCES</b></span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
    </button>
    <span class="lp-cf-h">Optional · narrows the list of applications</span>
  </div>
  <div class="lp-cf-cs">
    <button type="button" class="lp-sel2" aria-haspopup="listbox">
      <span class="lp-sel2-n lp-ok"><svg class="lp-i lp-b" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><span><small>Application *</small><b class="">FMCES</b></span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
    </button>
  </div>
  <div class="lp-cf-cs">
    <button type="button" class="lp-sel2 lp-on" aria-haspopup="listbox">
      <span class="lp-sel2-n">3</span><span><small>Entitlement *</small><b class="lp-ph">Select entitlement</b></span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
    </button>
    <span class="lp-cf-h">12 entitlements in FMCES</span>
  </div>
</div>
```

## Rail — progress

`.lp-cf-pn` big count, `.lp-cf-pb` one segment per required field (`lp-d` done, `lp-b` issue), `.lp-cf-pr` one row per section (`lp-cur` = current). From `reference/01-application-create.html`.

```html
<div class="lp-cf-rc lp-rz" style="--d: 1">
  <p class="lp-cf-rh">Progress<b>3 of 7 required</b></p>
  <div class="lp-cf-pn">
    <b class="">3</b><span>/ 7</span><small>required fields done</small>
  </div>
  <div class="lp-cf-pb" aria-hidden="true">
    <i class="lp-d" style="--k: 0"></i><i class="lp-d" style="--k: 1"></i><i class="lp-d" style="--k: 2"></i><i class="" style="--k: 3"></i><i class="" style="--k: 4"></i><i class="" style="--k: 5"></i><i class="" style="--k: 6"></i>
  </div>
  <div class="lp-cf-pl2">
    <button type="button" class="lp-cf-pr lp-cur">
      <span class="lp-m lp-cur">1</span><span class="lp-n">ITAM &amp; ownership</span><span class="lp-s">3 of 6</span>
    </button>
    <button type="button" class="lp-cf-pr">
      <span class="lp-m lp-op2">2</span><span class="lp-n">Change &amp; onboarding</span><span class="lp-s lp-op2">Optional</span>
    </button>
    <button type="button" class="lp-cf-pr">
      <span class="lp-m">3</span><span class="lp-n">OLA document</span><span class="lp-s">0 of 1</span>
    </button>
  </div>
</div>
```

## Rail — After you submit (Create)

From `reference/01-application-create.html`.

```html
<div class="lp-cf-rc lp-rz" style="--d: 2">
  <p class="lp-cf-rh">After you submit</p>
  <div class="lp-cf-tl">
    <div class="lp-cf-tlr lp-draft lp-cur">
      <span class="lp-d"></span>
      <div>
        <b>Draft<span class="lp-yh">You are here</span></b><small>You can keep editing</small>
      </div>
    </div>
    <div class="lp-cf-tlr lp-pend">
      <span class="lp-d"></span>
      <div>
        <b>Pending approval</b><small>A checker reviews it</small>
      </div>
    </div>
    <div class="lp-cf-tlr lp-appr">
      <span class="lp-d"></span>
      <div>
        <b>Approved</b><small>Locked as V1</small>
      </div>
    </div>
    <div class="lp-cf-tlr lp-live">
      <span class="lp-d"></span>
      <div>
        <b>Active</b><small>Ready to use</small>
      </div>
    </div>
  </div>
</div>
```

## Rail — Your changes (Edit)

From `reference/01-application-edit.html`.

```html
<div class="lp-cf-rc lp-rz" style="--d: 1">
  <p class="lp-cf-rh">Your changes<b style="color: var(--draft)">2 unsaved</b></p>
  <div class="lp-cf-chl">
    <div class="lp-cf-chr" style="--i: 0">
      <b>App owner</b>
      <div class="lp-ov">
        <s>1466717</s><svg class="lp-i lp-b" width="13" height="13" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><span>2023504</span>
      </div>
    </div>
    <div class="lp-cf-chr" style="--i: 1">
      <b>Description</b>
      <div class="lp-ov">
        <s>Maps RATAN roles to FMCES entitlements.</s><svg class="lp-i lp-b" width="13" height="13" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><span>Rule engine that maps RATAN business roles…</span>
      </div>
    </div>
  </div>
  <div class="lp-cf-rf">
    Compared with the approved version
    <button type="button" class="lp-lk">Discard all</button>
  </div>
</div>
```

## Rail — When you submit (Edit)

From `reference/01-application-edit.html`.

```html
<div class="lp-cf-rc lp-rz" style="--d: 3">
  <p class="lp-cf-rh">When you submit</p>
  <div class="lp-cf-tl">
    <div class="lp-cf-tlr lp-past">
      <span class="lp-d"></span>
      <div>
        <b>Approved · V2<span class="lp-vv">current</span></b><small>Live now; stays live until V3 is approved</small>
      </div>
    </div>
    <div class="lp-cf-tlr lp-draft lp-cur">
      <span class="lp-d"></span>
      <div>
        <b>Draft · V3<span class="lp-yh">You are here</span></b><small>Your changes; you can keep editing</small>
      </div>
    </div>
    <div class="lp-cf-tlr lp-pend">
      <span class="lp-d"></span>
      <div>
        <b>Pending approval</b><small>A checker reviews the changes</small>
      </div>
    </div>
    <div class="lp-cf-tlr lp-appr">
      <span class="lp-d"></span>
      <div>
        <b>Approved · V3</b><small>Replaces V2</small>
      </div>
    </div>
  </div>
</div>
```

## Rail — Paste from Excel tips (Features / Actions)

From `reference/03-feature-create.html`.

```html
<div class="lp-cf-rc lp-rz" style="--d: 2">
  <p class="lp-cf-rh">Paste from Excel</p>
  <div class="lp-cf-xl" aria-hidden="true">
    <div class="lp-h">
      <span></span><span>A · Name</span><span>B · Description</span>
    </div>
    <div>
      <span>1</span><span>Trade Booking</span><span>Book and amend…</span>
    </div>
    <div>
      <span>2</span><span>Position Viewer</span><span>Read-only view…</span>
    </div>
  </div>
  <div class="lp-cf-tip">
    <div>
      <kbd>Ctrl</kbd><kbd>V</kbd><span>pastes every row at once</span>
    </div>
    <div>
      <kbd>Tab</kbd><span>next cell</span><kbd>Enter</kbd><span>next row</span>
    </div>
    <div>
      <svg class="lp-i" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v6M12 7.5v.01"/></svg><span>Duplicates and empty cells show in Check</span>
    </div>
  </div>
</div>
```

## Rail — Summary (Create account)

From `reference/08-account-create.html`.

```html
<div class="lp-cf-rc lp-rz" style="--d: 2">
  <p class="lp-cf-rh">Summary</p>
  <p class="lp-cf-sum">Person account <b>1466717</b>, owned by <b>1466717</b>, will get <b class="lp-phd">an entitlement</b> in <b class="lp-t">FMCES</b>.</p>
</div>
```

## Action bar — Create

Sticky at the bottom of the main column. From `reference/01-application-create.html`.

```html
<div class="lp-cf-ab" role="region" aria-label="Form actions">
  <span class="lp-rqn"><b>*</b>Required</span><span class="lp-sep"></span><span class="lp-msg"><svg class="lp-i" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v6M12 7.5v.01"/></svg>Not saved yet</span><span class="lp-grow"></span>
  <button type="button" class="lp-btn lp-btn-q">
    <svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12a8 8 0 1 0 2.3-5.7M4 4v5h5"/></svg>Reset
  </button>
  <button type="button" class="lp-btn lp-btn-g">
    <svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h11l3 3v13H5zM8 4v5h7V4M8 20v-6h8v6"/></svg>Save draft
  </button>
  <button type="button" class="lp-btn lp-btn-p">
    <svg class="lp-i lp-b" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12 20 4l-6 16-3-7z"/></svg>Submit for approval
  </button>
</div>
```

## Action bar — Edit

From `reference/01-application-edit.html`.

```html
<div class="lp-cf-ab" role="region" aria-label="Form actions">
  <span class="lp-rqn"><b>*</b>Required</span><span class="lp-sep"></span><span class="lp-msg lp-chg"><i></i>2 unsaved changes</span><span class="lp-grow"></span>
  <button type="button" class="lp-btn lp-btn-q">
    <svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12a8 8 0 1 0 2.3-5.7M4 4v5h5"/></svg>Discard changes
  </button>
  <button type="button" class="lp-btn lp-btn-g">
    <svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h11l3 3v13H5zM8 4v5h7V4M8 20v-6h8v6"/></svg>Save draft
  </button>
  <button type="button" class="lp-btn lp-btn-p">
    <svg class="lp-i lp-b" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12 20 4l-6 16-3-7z"/></svg>Submit for approval
  </button>
</div>
```

## Picker — Select data policies

Scrim `.lp-cf-pks` + panel `.lp-cf-pk`. Rows `.lp-cf-pki` (`lp-on` ticked, `lp-open` details shown). From `reference/07-entitlement-create-pick-policies.html`.

```html
<div class="lp-cf-pks" aria-hidden="true">
</div>
<aside class="lp-cf-pk" role="dialog" aria-label="Select data policies">
  <div class="lp-cf-pk-h">
    <div>
      <small>New entitlement</small>
      <h2>Select data policies</h2>
    </div>
    <kbd>Esc</kbd>
    <button type="button" class="lp-ibx" aria-label="Close">
      <svg class="lp-i" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>
    </button>
  </div>
  <div class="lp-cf-pk-t">
    <label class="lp-sr">
      <svg class="lp-i" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4"/></svg>
      <input type="search" placeholder="Search by name, ID or owner">
    </label>
    <div class="lp-vseg" role="tablist">
      <span class="lp-ind" style="transform: translateX(0%)"></span>
      <button type="button" role="tab" class="lp-on">All <em>45</em></button>
      <button type="button" role="tab">Selected <em>1</em></button>
    </div>
  </div>
  <div class="lp-cf-pk-b">
    <div class="lp-cf-pki lp-on lp-open" style="--i: 0">
      <div class="lp-cf-pki-r">
        <button type="button" class="lp-cf-pkc" role="checkbox" aria-checked="true" aria-label="Select RATAN - OM Onshore User">
          <svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
        </button>
        <button type="button" class="lp-cf-pki-m" aria-expanded="true">
          <b>RATAN - OM Onshore User</b><small>2021102 · Desk in OM Onshore</small>
        </button>
        <span class="lp-id">#192</span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
      </div>
      <div class="lp-cf-pkd">
        <div class="lp-kvs">
          <span class="lp-kv3"><small>ID</small><b>#192</b></span><span class="lp-kv3"><small>Owner</small><b>2021102</b></span><span class="lp-kv3"><small>Modified</small><b>18 Oct 2026</b></span><span class="lp-kv3 lp-ok"><i></i><b>Active</b></span>
        </div>
        <h4>Conditions</h4>
        <div class="lp-cf-ctt">
          <div class="lp-cf-ctt-h">
            <span>Field</span><span>Operator</span><span>Values</span><span>Logic</span>
          </div>
          <div class="lp-cf-ctt-r">
            <span class="lp-k">Booking_Location</span><span class="lp-op">IN</span><span class="lp-vcs"><span class="lp-vc"><em>SG</em>Singapore</span></span><span class="lp-lg">—</span>
          </div>
          <div class="lp-cf-ctt-r">
            <span class="lp-k">Desk</span><span class="lp-op">IN</span><span class="lp-vcs"><span class="lp-vc lp-pl">OM Onshore</span></span><span class="lp-lg">AND</span>
          </div>
        </div>
      </div>
    </div>
    <div class="lp-cf-pki" style="--i: 1">
      <div class="lp-cf-pki-r">
        <button type="button" class="lp-cf-pkc" role="checkbox" aria-checked="false" aria-label="Select RATAN - BW Onshore User">
          <svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
        </button>
        <button type="button" class="lp-cf-pki-m" aria-expanded="false">
          <b>RATAN - BW Onshore User</b><small>2021102 · Desk in BW Onshore</small>
        </button>
        <span class="lp-id">#193</span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    </div>
    <div class="lp-cf-pki" style="--i: 2">
      <div class="lp-cf-pki-r">
        <button type="button" class="lp-cf-pkc" role="checkbox" aria-checked="false" aria-label="Select RATAN - CI Onshore User">
          <svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
        </button>
        <button type="button" class="lp-cf-pki-m" aria-expanded="false">
          <b>RATAN - CI Onshore User</b><small>2021102 · Desk in CI Onshore</small>
        </button>
        <span class="lp-id">#194</span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    </div>
    <div class="lp-cf-pki" style="--i: 3">
      <div class="lp-cf-pki-r">
        <button type="button" class="lp-cf-pkc" role="checkbox" aria-checked="false" aria-label="Select RATAN - JE Onshore User">
          <svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
        </button>
        <button type="button" class="lp-cf-pki-m" aria-expanded="false">
          <b>RATAN - JE Onshore User</b><small>2021102 · Desk in JE Onshore</small>
        </button>
        <span class="lp-id">#195</span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    </div>
    <div class="lp-cf-pki" style="--i: 4">
      <div class="lp-cf-pki-r">
        <button type="button" class="lp-cf-pkc" role="checkbox" aria-checked="false" aria-label="Select RATAN - BH Onshore User">
          <svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
        </button>
        <button type="button" class="lp-cf-pki-m" aria-expanded="false">
          <b>RATAN - BH Onshore User</b><small>2021102 · Desk in BH Onshore</small>
        </button>
        <span class="lp-id">#196</span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    </div>
    <div class="lp-cf-pki" style="--i: 5">
      <div class="lp-cf-pki-r">
        <button type="button" class="lp-cf-pkc" role="checkbox" aria-checked="false" aria-label="Select Policy Versioning Testing">
          <svg class="lp-i lp-b" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
        </button>
        <button type="button" class="lp-cf-pki-m" aria-expanded="false">
          <b>Policy Versioning Testing</b><small>g.iam.fmces.002.dev · Booking_Location in KR, SG</small>
        </button>
        <span class="lp-id">#164</span><svg class="lp-i lp-b lp-chev" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    </div>
  </div>
  <div class="lp-cf-pk-f">
    <div class="lp-grow">
      <span class="lp-cf-chq">RATAN - OM Onshore User <em>#192</em>
      <button type="button" aria-label="Remove RATAN - OM Onshore User">
        <svg class="lp-i lp-b" width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>
      </button>
      </span>
    </div>
    <button type="button" class="lp-btn lp-btn-g">Cancel</button>
    <button type="button" class="lp-btn lp-btn-p">
      <svg class="lp-i lp-b" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>Add 1 policy
    </button>
  </div>
</aside>
```

