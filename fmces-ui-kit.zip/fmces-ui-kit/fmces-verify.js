/*
 * FMCES list & report pages: self-check (v2)
 * ------------------------------------------------------------
 * Run it on every page and state listed in PROMPT.md, in the browser where the app runs (http://localhost:8001).
 *
 *   1. Paste this whole file into the browser console (or evaluate it with your browser tool).
 *   2. Then run:   await lpVerify()
 *
 * It prints PASS / FAIL / WARN for each check with the expected and the actual value,
 * shows a panel in the bottom-right corner of the page, and returns a summary object.
 * Keep the mouse pointer OUTSIDE the table while it runs (it checks that the edit pencil is hidden until hover).
 *
 * Options: await lpVerify({ overlay: false })   – no panel
 *          await lpVerify({ highlight: true })  – outline failing elements in red
 */
(function () {
  const TOKENS = { '--bg': '#0F1A22', '--accent': '#2DD4BF', '--accent2': '#5EEAD4', '--text': '#E6EEF2', '--muted': '#86A0AE', '--card': '#152733', '--border': '#23394A' };
  const C = {
    accent: 'rgb(45, 212, 191)', on: 'rgb(6, 42, 38)', text: 'rgb(230, 238, 242)', text2: 'rgb(167, 184, 196)', muted: 'rgb(134, 160, 174)',
    accent2: 'rgb(94, 234, 212)', border: 'rgb(35, 57, 74)', btn: 'rgb(43, 69, 86)', transparent: 'rgba(0, 0, 0, 0)'
  };
  const PAGES = ['app-management', 'data-profiles', 'data-policies', 'entitlement-management', 'entitlement-users', 'reports', 'fmid-reports'];
  const LISTS = ['app-management', 'data-profiles', 'data-policies', 'entitlement-management'];

  async function lpVerify(opts) {
    opts = Object.assign({ overlay: true, highlight: false }, opts || {});
    await new Promise((res) => setTimeout(res, 600)); // let hover/transition styles settle
    const R = [];
    const add = (status, area, check, expected, actual, el) => R.push({ status, area, check, expected: expected === undefined ? '' : String(expected), actual: actual === undefined ? '' : String(actual), el: el || null });
    const ok = (cond, area, check, expected, actual, el, soft) => add(cond ? 'PASS' : (soft ? 'WARN' : 'FAIL'), area, check, expected, actual, el);
    const $ = (s, r) => (r || document).querySelector(s);
    const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
    const cs = (el) => getComputedStyle(el);
    const n = (v) => Math.round(parseFloat(v) * 10) / 10;
    const near = (a, b, t) => Math.abs(parseFloat(a) - b) <= (t === undefined ? 1 : t);
    const vis = (el) => !!el && el.getClientRects().length > 0 && cs(el).visibility !== 'hidden';
    const txt = (el) => (el ? el.textContent.replace(/\s+/g, ' ').trim() : '');
    const path = (el) => {
      if (!el) return '';
      const parts = []; let e = el;
      for (let i = 0; e && e.nodeType === 1 && i < 3; i++, e = e.parentElement) {
        const cl = Array.from(e.classList || []).slice(0, 3).join('.');
        parts.unshift(e.tagName.toLowerCase() + (cl ? '.' + cl : ''));
      }
      return parts.join(' > ');
    };

    // ---------- root
    const roots = $$('.lp-root');
    const root = roots.find((r) => r.hasAttribute('data-lp-page')) || null;
    ok(!!root, 'Setup', 'A wrapper <div class="lp-root" data-lp-page="…"> around the page content', 'present', root ? 'present' : (roots.length ? '.lp-root without data-lp-page' : 'missing'));
    if (!root) return finish();
    const page = root.getAttribute('data-lp-page');
    ok(PAGES.indexOf(page) !== -1, 'Setup', 'data-lp-page is one of ' + PAGES.join(', '), PAGES.join('|'), page);
    ok($$('.lp-root[data-lp-page]').length === 1, 'Setup', 'Exactly one .lp-root[data-lp-page] on the page', 1, $$('.lp-root[data-lp-page]').length);

    // ---------- stylesheet + tokens
    const rcs = cs(root);
    Object.keys(TOKENS).forEach((k) => {
      const v = rcs.getPropertyValue(k).trim().toUpperCase();
      ok(v === TOKENS[k], 'Stylesheet', 'Token ' + k + ' on .lp-root (fmces-pages.css loaded, unedited)', TOKENS[k], v || '(empty)');
    });
    const probe = document.createElement('button'); probe.className = 'lp-btn lp-btn-p'; probe.textContent = 'x'; probe.style.position = 'absolute'; probe.style.left = '-9999px';
    root.appendChild(probe);
    ok(cs(probe).backgroundColor === C.accent, 'Stylesheet', 'Scoped rules apply (a test .lp-btn.lp-btn-p is teal)', C.accent, cs(probe).backgroundColor);
    probe.remove();
    let hoverRule = false; let sheetsBlocked = 0;
    Array.from(document.styleSheets).forEach((sh) => {
      let rules; try { rules = sh.cssRules; } catch (e) { sheetsBlocked++; return; }
      const scan = (list) => Array.from(list || []).forEach((r) => { if (r.selectorText && r.selectorText.indexOf('.lp-xt-r:hover .lp-xt-act .lp-rab') !== -1) hoverRule = true; if (r.cssRules) scan(r.cssRules); });
      scan(rules);
    });
    ok(hoverRule, 'Stylesheet', 'fmces-pages.css v2 is the copy in use (has the hover-pencil rule)', 'rule found', hoverRule ? 'rule found' : ('not found' + (sheetsBlocked ? ' (' + sheetsBlocked + ' sheets unreadable)' : '')));

    // ---------- fonts
    if (document.fonts && document.fonts.ready) { try { await document.fonts.ready; } catch (e) { /* ignore */ } }
    ok(/Manrope/i.test(rcs.fontFamily), 'Fonts', 'Manrope is the font of .lp-root', 'Manrope…', rcs.fontFamily);
    const manropeOk = document.fonts ? document.fonts.check('300 36px Manrope') && Array.from(document.fonts).some((f) => /Manrope/i.test(f.family) && f.status === 'loaded') : true;
    ok(manropeOk, 'Fonts', 'Manrope webfont is actually loaded (weights 200–800)', 'loaded', manropeOk ? 'loaded' : 'not loaded – add the Google Fonts link from PROMPT.md');
    const monoOk = document.fonts ? Array.from(document.fonts).some((f) => /JetBrains Mono/i.test(f.family) && f.status === 'loaded') : true;
    ok(monoOk, 'Fonts', 'JetBrains Mono webfont is loaded', 'loaded', monoOk ? 'loaded' : 'not loaded', null, true);

    // ---------- page wrapper + header
    const pg = $('.lp-pg', root);
    ok(!!pg, 'Page', '.lp-pg wrapper inside .lp-root', 'present', pg ? 'present' : 'missing');
    const aur = $('.lp-aur', root);
    ok(!!aur && $$('i', aur).length === 2, 'Page', 'Background glow .lp-aur with two <i> blobs', '2 blobs', aur ? $$('i', aur).length + ' blobs' : 'missing');
    const ph = $('.lp-ph', root);
    ok(!!ph, 'Header', 'Page header .lp-ph', 'present', ph ? 'present' : 'missing');
    const pt = $('.lp-pt', root);
    if (pt) {
      const s = cs(pt);
      const tsz = window.matchMedia('(max-width: 900px)').matches ? 28 : 36;
      ok(near(s.fontSize, tsz) && s.fontWeight === '300', 'Header', 'Title .lp-pt is ' + tsz + 'px / 300', tsz + 'px / 300', s.fontSize + ' / ' + s.fontWeight, pt);
      ok(s.color === C.text, 'Header', 'Title colour', C.text, s.color, pt);
    } else ok(false, 'Header', 'Title .lp-pt', 'present', 'missing');
    const eb = $('.lp-eb b', root);
    ok(!!eb && /^\d\d$/.test(txt(eb)), 'Header', 'Eyebrow number (.lp-eb b) like "01"', '01–07', eb ? txt(eb) : 'missing');
    const bign = $('.lp-bign', root);
    ok(!!bign && eb && txt(bign) === txt(eb), 'Header', 'Watermark number .lp-bign matches the eyebrow', eb ? txt(eb) : '01–07', bign ? txt(bign) : 'missing');
    const pa = $('.lp-pa', root);
    if (pa) {
      const acts = $$(':scope > button, :scope > a, :scope > .lp-anc > button, :scope > .lp-anc > a', pa);
      const notBtn = acts.filter((b) => !b.classList.contains('lp-btn'));
      ok(notBtn.length === 0, 'Header', 'Every header action button has class lp-btn (no library buttons)', '0 without lp-btn', notBtn.length + (notBtn.length ? ': ' + notBtn.map((b) => '"' + txt(b) + '"').join(', ') : ''), notBtn[0]);
      acts.filter((b) => b.classList.contains('lp-btn-p') && !b.classList.contains('lp-on') && !b.matches(':hover')).forEach((b) => {
        const s = cs(b);
        ok(s.backgroundColor === C.accent && (s.backgroundImage === 'none' || s.backgroundImage === ''), 'Header', 'Primary button "' + txt(b) + '" is solid teal #2DD4BF', C.accent + ', no gradient', s.backgroundColor + (s.backgroundImage !== 'none' ? ' + ' + s.backgroundImage.slice(0, 40) : ''), b);
        ok(s.color === C.on, 'Header', 'Primary button "' + txt(b) + '" text colour', C.on, s.color, b);
        ok(near(s.height, 38), 'Header', 'Primary button "' + txt(b) + '" height', '38px', s.height, b);
      });
      acts.filter((b) => b.classList.contains('lp-btn-g') && !b.classList.contains('lp-on') && !b.matches(':hover')).forEach((b) => {
        const s = cs(b);
        ok(s.borderTopColor === C.btn, 'Header', 'Secondary button "' + txt(b) + '" border', C.btn, s.borderTopColor, b);
      });
    }

    // ---------- colour audit: no "ocean blue" anywhere in the page
    const blueHits = [];
    const hsl = (r, g, b) => { r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let h = 0, s = 0; const l = (mx + mn) / 2; if (mx !== mn) { const d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60; } return [h, s * 100, l * 100]; };
    const isBlue = (str, minA) => {
      const re = /rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?\)/g; let m;
      while ((m = re.exec(str))) {
        const a = m[4] === undefined ? 1 : parseFloat(m[4]); if (a < minA) continue;
        const [h, s, l] = hsl(+m[1], +m[2], +m[3]);
        if (h >= 195 && h <= 235 && s >= 55 && l >= 28 && l <= 70) return m[0];
      }
      return null;
    };
    const all = [root].concat($$('*', root)).filter((el) => !el.closest('.lp-aur') && vis(el));
    all.forEach((el) => {
      const s = cs(el);
      const hit = isBlue(s.color, 0.3) || isBlue(s.backgroundColor, 0.25) || isBlue(s.borderTopColor, 0.4) || isBlue(s.borderBottomColor, 0.4) || isBlue(s.backgroundImage, 0.25);
      if (hit) blueHits.push([el, hit]);
    });
    ok(blueHits.length === 0, 'Colours', 'No "ocean blue" (#1E88E5 / #2196F3 / #1976D2 family) anywhere in the page — use the teal tokens', '0 elements',
      blueHits.length + (blueHits.length ? ' — e.g. ' + blueHits.slice(0, 6).map((x) => path(x[0]) + ' ' + x[1]).join(' | ') : ''), blueHits[0] && blueHits[0][0]);

    // ---------- the mockup grid classes must never be used
    const banned = $$('.lp-tb, .lp-tr, .lp-td, .lp-thc, .lp-tbd, .lp-tw, .lp-gx, .lp-gxr, .lp-gxc, .lp-ra', root);
    ok(banned.length === 0, 'Tables', 'No mockup grid classes (lp-tb/tr/td/thc/tbd/tw/gx*/ra) — use the lp-xt-* adapter on your table', '0', banned.length + (banned.length ? ' e.g. ' + path(banned[0]) : ''), banned[0]);

    // ---------- shared table checks
    const checkTable = (area, tbl, o) => {
      o = o || {};
      if (!tbl) { ok(false, area, 'Table with class lp-xt', 'present', 'missing'); return; }
      const wrap = tbl.closest('.lp-xt-wrap');
      ok(!!wrap, area, 'Table sits inside .lp-xt-wrap', 'present', wrap ? 'present' : 'missing', tbl);
      const ths = $$('.lp-xt-th', tbl).filter(vis);
      ok(ths.length >= 2, area, 'Header cells have class lp-xt-th', '≥ 2', ths.length, tbl);
      const plain = ths.find((t) => !t.classList.contains('lp-on') && txt(t).length > 1) || ths[0];
      if (plain) {
        const s = cs(plain);
        ok(near(plain.getBoundingClientRect().height, o.dense ? 38 : 42, 1.5), area, 'Header row height', (o.dense ? 38 : 42) + 'px', n(plain.getBoundingClientRect().height) + 'px', plain);
        ok(near(s.fontSize, o.dense ? 10.5 : 11, 0.3) && s.textTransform === 'uppercase', area, 'Header text: ' + (o.dense ? '10.5' : '11') + 'px uppercase', (o.dense ? '10.5' : '11') + 'px uppercase', s.fontSize + ' ' + s.textTransform, plain);
        ok(s.color === C.muted, area, 'Header text colour (muted)', C.muted, s.color, plain);
        const bg = s.backgroundColor; const okBg = bg === C.transparent || bg === 'rgb(19, 35, 46)';
        ok(okBg, area, 'Header cell background is transparent (or #13232E when sticky)', 'transparent | rgb(19, 35, 46)', bg, plain);
      }
      const rows = $$('.lp-xt-r', tbl).filter(vis);
      ok(rows.length >= 1 || o.allowEmpty, area, 'Body rows have class lp-xt-r', '≥ 1', rows.length, tbl, o.allowEmpty);
      const r0 = rows.find((r) => !r.matches(':hover') && !r.classList.contains('lp-pinned') && !r.classList.contains('lp-sel')) || rows[0];
      if (r0) {
        const tds = $$('.lp-xt-td', r0);
        ok(tds.length >= 2, area, 'Body cells have class lp-xt-td', '≥ 2 per row', tds.length, r0);
        const td = tds.find((t) => !t.classList.contains('lp-xt-num') && !t.classList.contains('lp-xt-act') && !t.classList.contains('lp-xt-stk') && !t.querySelector('.lp-pin')) || tds[0];
        if (td) {
          const s = cs(td);
          if (!o.dense) ok(near(r0.getBoundingClientRect().height, 54, 1.5), area, 'Row height', '54px', n(r0.getBoundingClientRect().height) + 'px', r0);
          else ok(r0.getBoundingClientRect().height >= 50, area, 'Dense row height', '≥ 52px', n(r0.getBoundingClientRect().height) + 'px', r0);
          ok(near(s.fontSize, o.dense ? 12.5 : 13, 0.3), area, 'Cell text size', (o.dense ? '12.5' : '13') + 'px', s.fontSize, td);
          ok(s.color === C.text2, area, 'Cell text colour', C.text2, s.color, td);
          ok(s.borderBottomColor === 'rgba(30, 50, 64, 0.65)', area, 'Row divider colour', 'rgba(30, 50, 64, 0.65)', s.borderBottomColor, td);
          ok(s.backgroundColor === C.transparent, area, 'Cell background is transparent when not hovered', C.transparent, s.backgroundColor, td);
        }
      }
      return { ths: ths, rows: rows };
    };
    const colIndex = (tbl, re) => {
      const hr = $$('thead tr, .lp-xt-hr', tbl).pop() || null;
      const ths = hr ? $$('.lp-xt-th', hr) : $$('.lp-xt-th', tbl);
      return ths.findIndex((t) => re.test(txt(t)));
    };
    const cellAt = (row, i) => $$('.lp-xt-td', row)[i];

    const checkListCard = (area) => {
      const card = $('.lp-cd', root);
      ok(!!card, area, 'List card .lp-cd', 'present', card ? 'present' : 'missing');
      if (!card) return;
      const s = cs(card);
      ok(/linear-gradient/.test(s.backgroundImage), area, 'Card has its gradient background', 'linear-gradient(…)', s.backgroundImage.slice(0, 60), card);
      ok(near(s.borderTopLeftRadius, 18), area, 'Card corner radius', '18px', s.borderTopLeftRadius, card);
      ok(s.borderTopColor === C.border, area, 'Card border colour', C.border, s.borderTopColor, card);
      const nofacts = root.hasAttribute('data-lp-nofacts');
      const facts = $$('.lp-fb', card);
      if (nofacts) add('WARN', area, 'Facts row skipped (data-lp-nofacts) — agreed with the user?', '', '');
      else {
        ok(facts.length >= 2, area, 'Facts row (.lp-fb buttons) INSIDE the list card, left of the toolbar', '≥ 2 inside .lp-cd', facts.length + ' inside card, ' + $$('.lp-fb', root).length + ' on page', card);
        const fn = $('.lp-fb-n', card);
        if (fn) ok(near(cs(fn).fontSize, 30) && cs(fn).fontWeight === '300', area, 'Fact number 30px / 300', '30px / 300', cs(fn).fontSize + ' / ' + cs(fn).fontWeight, fn);
        if (facts[0]) ok(/^\s*\d+\s*All\s*$/i.test(txt(facts[0])) || /All/.test(txt(facts[0])), area, 'First fact is "All"', 'All', txt(facts[0]), facts[0]);
        const dist = $('.lp-dist', card);
        ok(!!dist && $$('i', dist).length >= 1, area, 'Mix bar .lp-dist under the facts', '≥ 1 segment', dist ? $$('i', dist).length : 'missing', card);
      }
      const sr = $('.lp-sr', card);
      ok(!!sr && !!$('input', sr), area, 'Search field .lp-sr with an input', 'present', sr ? 'present' : 'missing', card);
      if (sr) ok(near(cs(sr).height, 38), area, 'Search height', '38px', cs(sr).height, sr);
      const ibx = $$('.lp-tl .lp-ibx', card);
      ok(ibx.length >= 1, area, 'Icon buttons .lp-ibx in the toolbar (refresh / filter)', '≥ 1', ibx.length, card);
      ibx.forEach((b) => ok(near(cs(b).width, 38) && near(cs(b).height, 38), area, 'Icon button is 38×38', '38×38', n(cs(b).width) + '×' + n(cs(b).height), b));
      const ex = $$('.lp-tl .lp-btn', card).find((b) => /export/i.test(txt(b)));
      ok(!!ex && ex.classList.contains('lp-btn-g'), area, 'Export button is .lp-btn.lp-btn-g', 'present', ex ? ex.className : 'missing', ex || card);
      const chips = $$('.lp-colbar .lp-cch', card);
      ok(chips.length >= 3, area, 'Column chips .lp-cch in .lp-colbar (all columns, hidden ones too)', '≥ 3', chips.length, card);
      const onChip = chips.find((c) => c.classList.contains('lp-on') && !c.classList.contains('lp-req'));
      if (onChip) ok(cs(onChip).backgroundColor === 'rgba(45, 212, 191, 0.08)' && cs(onChip).color === C.text, area, 'Visible-column chip: teal tint + check, light text', 'rgba(45, 212, 191, 0.08) / ' + C.text, cs(onChip).backgroundColor + ' / ' + cs(onChip).color, onChip);
      const tbl = $('.lp-xt', card);
      const t = checkTable(area, tbl);
      if (!tbl) return;
      ok(tbl.classList.contains('lp-xt-click'), area, 'Table has lp-xt-click (rows open the drawer)', 'lp-xt-click', tbl.className, tbl);
      const rz = $$('.lp-xt-th .lp-xt-rz', tbl);
      ok(rz.length >= 1, area, 'Column resize handles carry .lp-xt-rz (inside the header cells)', '≥ 1', rz.length, tbl);
      ok(!!$('.lp-xt-num', tbl), area, '"#" column cells have lp-xt-num', 'present', $('.lp-xt-num', tbl) ? 'present' : 'missing', tbl);
      ok(!!$('.lp-xt-r .lp-pin', tbl), area, 'Pin buttons .lp-pin in the rows', 'present', $('.lp-xt-r .lp-pin', tbl) ? 'present' : 'missing', tbl);
      const pencils = $$('.lp-xt-act .lp-rab', tbl);
      ok(pencils.length >= 1, area, 'Edit pencil is a .lp-rab inside a .lp-xt-act cell', '≥ 1', pencils.length, tbl);
      const idle = pencils.find((p) => !p.closest('.lp-xt-r').matches(':hover') && !p.closest('.lp-xt-r').matches(':focus-within'));
      if (idle) ok(parseFloat(cs(idle).opacity) === 0, area, 'Edit pencil is HIDDEN until the row is hovered', 'opacity 0', 'opacity ' + cs(idle).opacity, idle);
      const rows = t.rows.slice(0, 5);
      const iSt = colIndex(tbl, /^status\b/i);
      if (iSt >= 0 && rows.length) {
        const bad = rows.filter((r) => { const c = cellAt(r, iSt); return !c || !c.querySelector('.lp-lc, .lp-st'); });
        ok(bad.length === 0, area, 'Status column shows a dot + word (.lp-lc, or .lp-st for Enabled/Disabled), not a pill', 'all rows', (rows.length - bad.length) + '/' + rows.length, bad[0]);
        const lc = rows.map((r) => cellAt(r, iSt)).map((c) => c && c.querySelector('.lp-lc')).find(Boolean);
        if (lc) ok(cs(lc).backgroundColor === C.transparent, area, 'Status has no pill background', C.transparent, cs(lc).backgroundColor, lc);
      }
      const iAc = colIndex(tbl, /^active\b|^enabled\b/i);
      if (iAc >= 0 && rows.length) {
        const bad = rows.filter((r) => { const c = cellAt(r, iAc); return !c || !c.querySelector('.lp-st'); });
        ok(bad.length === 0, area, 'Active column shows a dot + word (.lp-st), not a pill', 'all rows', (rows.length - bad.length) + '/' + rows.length, bad[0]);
      }
      const iOla = colIndex(tbl, /^ola$/i);
      if (iOla >= 0 && rows.length) { const c = cellAt(rows[0], iOla); ok(!!(c && c.querySelector('.lp-ola')), area, 'OLA cell uses the .lp-ola icon button', 'present', c && c.querySelector('.lp-ola') ? 'present' : 'missing', c); }
      const iVer = colIndex(tbl, /^version$/i);
      if (iVer >= 0 && rows.length) { const c = cellAt(rows[0], iVer); ok(!!(c && c.querySelector('.lp-vr')), area, 'Version cell uses the .lp-vr pill', 'present', c && c.querySelector('.lp-vr') ? 'present' : 'missing', c, true); }
      const iDt = colIndex(tbl, /date|modified|created\b/i);
      if (iDt >= 0 && rows.length) { const c = cellAt(rows[0], iDt); ok(!!(c && c.querySelector('.lp-dt')), area, 'Date cells use .lp-dt (date + relative line)', 'present', c && c.querySelector('.lp-dt') ? 'present' : 'missing', c, true); }
      if (rows.length) ok(!!rows[0].querySelector('.lp-nmb .lp-mgx'), area, 'Name cell has the monogram tile (.lp-nmb > .lp-mgx)', 'present', rows[0].querySelector('.lp-nmb .lp-mgx') ? 'present' : 'missing', rows[0], true);
      const tf = $('.lp-tf', card);
      ok(!!tf, area, 'Footer .lp-tf', 'present', tf ? 'present' : 'missing', card);
      if (tf) {
        const seg = $$('.lp-seg button', tf).map(txt);
        ok(['15', '25', '50'].every((x) => seg.indexOf(x) !== -1), area, 'Rows per page 15 / 25 / 50 in .lp-seg', '15,25,50', seg.join(','), tf);
      }
    };

    // ---------- per page
    let state = '';
    if (LISTS.indexOf(page) !== -1) {
      if (page === 'app-management') {
        const gt = $('.lp-gt[role="tablist"]', root);
        ok(!!gt, 'Tabs', 'Glass tabs .lp-gt[role=tablist] (not underline tabs)', 'present', gt ? 'present' : 'missing');
        if (gt) {
          const tabs = $$('button[role="tab"]', gt);
          ok(tabs.length >= 3 && tabs.length <= 4, 'Tabs', 'Tab buttons inside .lp-gt', '3 or 4', tabs.length, gt);
          ok(cs(gt).getPropertyValue('--n').trim() === String(tabs.length), 'Tabs', '--n equals the number of visible tabs', tabs.length, cs(gt).getPropertyValue('--n').trim(), gt);
          ok(!!$('.lp-ind', gt), 'Tabs', 'Sliding indicator .lp-ind', 'present', $('.lp-ind', gt) ? 'present' : 'missing', gt);
          const on = tabs.find((b) => b.classList.contains('lp-on'));
          ok(!!on, 'Tabs', 'Active tab has lp-on', 'present', on ? txt(on) : 'missing', gt);
          state = on ? txt(on).replace(/\d+$/, '').trim() : '';
          if (on && /feature|action/i.test(txt(on))) {
            ok(!!$('.lp-scx .lp-scf', root), 'Application band', 'Features/Actions: application band .lp-scx with the .lp-scf trigger', 'present', $('.lp-scx .lp-scf', root) ? 'present' : 'missing');
          }
        }
        const stray = $$('[role="tab"]', root).filter((t) => !t.closest('.lp-gt, .lp-vseg, .lp-bseg'));
        ok(stray.length === 0, 'Tabs', 'No leftover old tabs outside the glass control', '0', stray.length, stray[0]);
        const nb = $$('.lp-pa .lp-btn-p', root)[0];
        ok(!!nb && !!$('.lp-chev2, svg:last-child', nb), 'Header', 'Add New is the teal dropdown button with a chevron', 'present', nb ? txt(nb) : 'missing', nb, true);
      }
      if (page === 'data-policies') {
        const up = $$('.lp-pa .lp-btn', root).find((b) => /upload/i.test(txt(b)));
        ok(!!up, 'Header', 'Upload button in the header actions (.lp-btn)', 'present', up ? 'present' : 'missing');
        const dlg = $('.lp-dlg', document);
        if (dlg) {
          state = 'upload dialog';
          ok(!!dlg.closest('.lp-root'), 'Upload', 'The dialog is inside an .lp-root (wrap portals in their own <div class="lp-root">)', 'inside', dlg.closest('.lp-root') ? 'inside' : 'outside', dlg);
          ok(!!$('.lp-dscrim', document) && !!dlg.closest('.lp-dw'), 'Upload', 'Dialog layer .lp-dw with the .lp-dscrim backdrop', 'present', '', dlg);
          ok(!!$('.lp-drop, .lp-fil', dlg), 'Upload', 'Drop zone .lp-drop (or file card .lp-fil)', 'present', $('.lp-drop, .lp-fil', dlg) ? 'present' : 'missing', dlg);
        }
      }
      const presets = $$('.lp-pa .lp-btn', root).find((b) => /preset/i.test(txt(b)));
      ok(!!presets && presets.classList.contains('lp-btn-g'), 'Header', 'Presets button is .lp-btn.lp-btn-g', 'present', presets ? presets.className : 'missing', presets);
      ok(!!$('.lp-ps .lp-sync', root), 'Header', 'Refresh line .lp-sync ("Updated …") in the subtitle line', 'present', $('.lp-ps .lp-sync', root) ? 'present' : 'missing', ph, true);
      checkListCard('List');
    }

    if (page === 'entitlement-users') {
      const f = $('.lp-fnd2', root);
      ok(!!f, 'Finder', 'Finder card .lp-fnd2', 'present', f ? 'present' : 'missing');
      if (f) {
        ok($$('.lp-sel2', f).length >= 2, 'Finder', 'Two big selects .lp-sel2 (ITAM Name → Application)', '2', $$('.lp-sel2', f).length, f);
        ok(!!$('.lp-qs', f), 'Finder', 'Quick search .lp-qs', 'present', $('.lp-qs', f) ? 'present' : 'missing', f);
        ok(!!$('.lp-fz-or', f), 'Finder', '"or" divider .lp-fz-or', 'present', $('.lp-fz-or', f) ? 'present' : 'missing', f);
        const sb = $('.lp-qs .lp-btn-p', f);
        ok(!!sb, 'Finder', 'Search button is .lp-btn.lp-btn-p', 'present', sb ? 'present' : 'missing', f);
      }
      const gt = $('.lp-gt[role="tablist"]', root);
      if (gt) {
        state = 'loaded';
        ok($$('button[role="tab"]', gt).length === 2, 'Tabs', 'Accounts / Entitlements glass tabs', '2', $$('button[role="tab"]', gt).length, gt);
        ok(!!$('.lp-ctx', root), 'Tabs', 'Context card .lp-ctx next to the tabs', 'present', $('.lp-ctx', root) ? 'present' : 'missing', gt, true);
        checkListCard('List');
      } else {
        state = 'start';
        ok(!!$('.lp-hero0', root), 'Start', 'Start state .lp-hero0 with the ghost rows', 'present', $('.lp-hero0', root) ? 'present' : 'missing');
      }
    }

    if (page === 'reports') {
      const rb = $('.lp-rb', root); const rp = $('.lp-rp', root);
      ok(!!rb && !!rp, 'Reports', 'Two-column layout .lp-rb with the settings panel .lp-rp', 'present', rb && rp ? 'present' : 'missing');
      ok($$('.lp-rs2', root).length >= 2, 'Reports', 'Numbered steps .lp-rs2', '≥ 2', $$('.lp-rs2', root).length);
      ok(!!$('.lp-rp .lp-sel2', root), 'Reports', 'Application select .lp-sel2', 'present', $('.lp-rp .lp-sel2', root) ? 'present' : 'missing');
      ok($$('.lp-rp .lp-tg', root).length >= 1, 'Reports', 'Field toggles .lp-tg', '≥ 1', $$('.lp-rp .lp-tg', root).length);
      ok($$('.lp-rp .lp-fmt', root).length >= 2, 'Reports', 'Format cards .lp-fmt (CSV / Excel / JSON)', '≥ 2', $$('.lp-rp .lp-fmt', root).length);
      const dl = $('.lp-rp-f .lp-btn-p', root); const gp = $('.lp-rp-f .lp-btn-g', root);
      ok(!!dl, 'Reports', 'Download Report is .lp-btn.lp-btn-p in .lp-rp-f', 'present', dl ? txt(dl) : 'missing');
      ok(!!gp, 'Reports', 'Generate Preview is .lp-btn.lp-btn-g in .lp-rp-f', 'present', gp ? txt(gp) : 'missing');
      const rv = $('.lp-rv', root);
      ok(!!rv, 'Reports', 'Preview card .lp-cd.lp-rv', 'present', rv ? 'present' : 'missing');
      const tbl = rv && $('.lp-xt', rv);
      if (tbl) { state = 'preview'; checkTable('Preview table', tbl); ok(!!$('.lp-doc-h', rv), 'Reports', 'Preview header .lp-doc-h with the search', 'present', $('.lp-doc-h', rv) ? 'present' : 'missing', rv); }
      else state = 'start';
    }

    if (page === 'fmid-reports') {
      ok(!!$('.lp-pgrid .lp-prm', root), 'Parameters', 'Parameters card .lp-prm inside .lp-pgrid', 'present', $('.lp-pgrid .lp-prm', root) ? 'present' : 'missing');
      ok(!!$('.lp-pgrid .lp-mxk', root), 'Parameters', 'Security matrix card .lp-mxk', 'present', $('.lp-pgrid .lp-mxk', root) ? 'present' : 'missing');
      ok($$('.lp-prm .lp-sel2', root).length >= 2, 'Parameters', 'ITAM ID and Application selects .lp-sel2', '2', $$('.lp-prm .lp-sel2', root).length);
      const bseg = $('.lp-prm .lp-bseg', root);
      ok(!!bseg && !!$('.lp-ind', bseg), 'Parameters', 'Bank ID(s) mode as .lp-bseg with .lp-ind', 'present', bseg ? 'present' : 'missing');
      ok($$('.lp-prm .lp-req-star', root).length >= 3, 'Parameters', 'Required asterisks .lp-req-star', '≥ 3', $$('.lp-prm .lp-req-star', root).length);
      const fb = $('.lp-prm-f .lp-btn-p', root);
      ok(!!fb, 'Parameters', 'Fetch Report is .lp-btn.lp-btn-p in .lp-prm-f', 'present', fb ? txt(fb) : 'missing');
      const mxBtn = $('.lp-mxk .lp-btn', root);
      ok(!!mxBtn, 'Parameters', 'Download Security Matrix is an .lp-btn in .lp-mxk', 'present', mxBtn ? txt(mxBtn) : 'missing');
      if ($('.lp-fet', root)) state = 'fetching';
      const rhd = $('.lp-rhd', root);
      if (rhd) {
        const vOn = $('.lp-vseg button.lp-on', root);
        state = 'results · ' + (vOn ? txt(vOn) : '?');
        const b = $('.lp-rhd-b', rhd);
        ok(!!b && near(cs(b).fontSize, 34), 'Results', 'User count .lp-rhd-b 34px', '34px', b ? cs(b).fontSize : 'missing', rhd);
        ok(!!$('.lp-vseg', rhd) && $$('.lp-vseg button', rhd).length === 2, 'Results', 'Detail / Matrix toggle .lp-vseg', '2 buttons', $$('.lp-vseg button', rhd).length, rhd);
        ok($$('.lp-xg button', rhd).length >= 3, 'Results', 'Export group .lp-xg (CSV / Excel / JSON)', '3', $$('.lp-xg button', rhd).length, rhd);
        ok($$('.lp-cd .lp-dd', root).length >= 1, 'Results', 'Filters styled .lp-dd', '≥ 1', $$('.lp-cd .lp-dd', root).length);
        ok($$('.lp-cd .lp-inf', root).length >= 1, 'Results', 'Filter info tooltips kept (.lp-inf triggers)', '≥ 1', $$('.lp-cd .lp-inf', root).length);
        const tbl = $('.lp-cd .lp-xt', root);
        if (tbl) {
          ok(tbl.classList.contains('lp-xt-dense') && tbl.classList.contains('lp-xt-sticky'), 'Results', 'Results table uses lp-xt lp-xt-dense lp-xt-sticky', 'dense + sticky', tbl.className, tbl);
          ok(!!$('.lp-xt-stk', tbl), 'Results', 'First (user) column is sticky (.lp-xt-stk)', 'present', $('.lp-xt-stk', tbl) ? 'present' : 'missing', tbl);
          checkTable('Results table', tbl, { dense: true });
          const heads = $$('thead tr:last-child .lp-xt-th, .lp-xt-th', tbl).map(txt).filter(Boolean);
          add('INFO', 'Results', 'Columns shown (' + heads.length + ') — compare with your Step 0 inventory, nothing may be missing', '', heads.join(' | '));
          if (vOn && /detail/i.test(txt(vOn))) ok(!!$('.lp-cgs .lp-tg', root), 'Results', 'COLUMNS group toggles .lp-cgs .lp-tg', 'present', $('.lp-cgs .lp-tg', root) ? 'present' : 'missing');
        } else ok(false, 'Results', 'Results table with lp-xt', 'present', 'missing');
      } else if (!state) state = 'start';
    }

    // ---------- dock glide (outside .lp-root)
    const dk = document.querySelector('.lp-dk-sl');
    ok(!!dk, 'Dock', 'Gliding highlight .lp-dk-sl in the dock', 'present', dk ? 'present' : 'missing');
    if (dk) ok(cs(dk).transitionProperty.indexOf('transform') !== -1, 'Dock', 'Highlight glides (transition on transform)', 'transform', cs(dk).transitionProperty, dk);

    return finish();

    function finish() {
      const pass = R.filter((r) => r.status === 'PASS').length, fail = R.filter((r) => r.status === 'FAIL').length, warn = R.filter((r) => r.status === 'WARN').length;
      const pg2 = (document.querySelector('.lp-root[data-lp-page]') || { getAttribute: () => '?' }).getAttribute('data-lp-page');
      const head = 'FMCES verify v2 — page: ' + pg2 + (state ? ' · ' + state : '') + ' — ' + pass + ' PASS, ' + fail + ' FAIL, ' + warn + ' WARN';
      try {
        console.log('%c' + head, 'font-weight:700;color:' + (fail ? '#F4A3A3' : '#2DD4BF'));
        console.table(R.filter((r) => r.status !== 'PASS').map((r) => ({ status: r.status, area: r.area, check: r.check, expected: r.expected, actual: r.actual })));
      } catch (e) { /* no console */ }
      if (opts.highlight) R.filter((r) => r.status === 'FAIL' && r.el).forEach((r) => { r.el.style.outline = '2px solid #F4A3A3'; r.el.style.outlineOffset = '2px'; });
      if (opts.overlay) panel(head, fail);
      const res = { page: pg2, state: state, pass: pass, fail: fail, warn: warn, summary: head,
        problems: R.filter((r) => r.status !== 'PASS').map((r) => r.status + ' [' + r.area + '] ' + r.check + ' — expected: ' + r.expected + ' — actual: ' + r.actual) };
      window.__lpVerifyLast = res;
      return res;
    }
    function panel(head, fail) {
      const old = document.getElementById('lp-verify-panel'); if (old) old.remove();
      const d = document.createElement('div'); d.id = 'lp-verify-panel';
      d.setAttribute('style', 'position:fixed;right:16px;bottom:16px;z-index:2147483647;width:520px;max-height:60vh;overflow:auto;background:#0B141B;color:#E6EEF2;border:2px solid ' + (fail ? '#F4A3A3' : '#2DD4BF') + ';border-radius:12px;padding:12px 14px;font:12px/1.45 ui-monospace,Menlo,Consolas,monospace;box-shadow:0 20px 60px rgba(0,0,0,.6)');
      const rows = R.filter((r) => r.status !== 'PASS').map((r) => '<div style="padding:6px 0;border-top:1px solid #1E3240"><b style="color:' + (r.status === 'FAIL' ? '#F4A3A3' : r.status === 'WARN' ? '#F6C177' : '#93C5FD') + '">' + r.status + '</b> [' + esc(r.area) + '] ' + esc(r.check) + (r.expected ? '<br><span style="color:#86A0AE">expected:</span> ' + esc(r.expected) : '') + (r.actual ? '<br><span style="color:#86A0AE">actual:</span> ' + esc(r.actual) : '') + '</div>').join('');
      d.innerHTML = '<div style="display:flex;gap:8px;align-items:center;margin-bottom:6px"><b style="flex:1;color:' + (fail ? '#F4A3A3' : '#2DD4BF') + '">' + esc(head) + '</b><button type="button" style="font:inherit;background:#1B3140;color:#E6EEF2;border:0;border-radius:6px;padding:3px 8px;cursor:pointer">close</button></div>' + (rows || '<div style="color:#2DD4BF">All checks passed.</div>');
      d.querySelector('button').onclick = () => d.remove();
      document.body.appendChild(d);
    }
    function esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]); }
  }

  window.lpVerify = lpVerify;
  if (/[?&]lpverify\b/.test(location.search)) setTimeout(() => lpVerify(), 2500);
})();
