# FMCES UI kit — markup (templates)

Framework-neutral HTML for every piece. Read PROMPT.md §4 first ("How to read the markup"). The rendered result of each template, with sample data, is in `reference/*.html` — open those to see exactly how it should look.

Notation: `{value}` = a value you compute; `<!-- if x -->…<!-- /if -->` = conditional; `<!-- for each a in list -->…<!-- /for -->` = repeat; `class="lp-a {lp-b [lp-c]|lp-d}"` = static classes plus a computed part (`[x]` optional, `a|b` one of); `<Icon name="…" size="…" bold class="…"/>` = the icon component (paths at the end of this file). Always bind YOUR existing handlers. Wording in the templates is a fallback; the app's own text always wins.

## B.1 Page wrapper

PROMPT §5. One per page, around everything right of the dock and below the workspace tabs. `data-lp-page` is required (the self-check reads it). `{lp-pga|lp-pgb}`: swap only if your router reuses the page component. `anyPopoverOpen` / `closePopover`: skip the scrim if your popovers already close on outside click.

```html
<div class="lp-root" data-lp-page="{app-management | data-profiles | data-policies | entitlement-management | entitlement-users | reports | fmid-reports}">
  <div class="lp-pg">
    <div class="lp-aur" aria-hidden="true">
      <i class="lp-a1"></i><i class="lp-a2"></i>
    </div>
    <div class="{lp-pga|lp-pgb}">
      <!-- if anyPopoverOpen -->
        <button type="button" class="lp-pscrim" aria-label="Close" onClick={closePopover}>
        </button>
      <!-- /if -->
      <!-- B.2 page header, then the page's own blocks: B.3 / B.4 / B.8 / B.9 / B.10 -->
    </div>
  </div>
  <!-- B.7 upload dialog (pages that have Upload) -->
  <!-- B.11 toast -->
</div>
```

## B.2 Page header, Presets popover, Add New menu

PROMPT §6.1. `{bign}` / `{pn}` = module number 01–07. `{pTitle}` / `{pSub}` = the app's title and subtitle. `{synced}` = the app's "Updated …" text; `syncGo` = existing refresh. `hasView` = page has Presets: `{viewT}` = applied preset name (e.g. "Page defaults"), `{viewN}` = number of presets, `views` = your presets (`v.n` name, `v.sub` meta, `v.pick` apply, `v.star` make default, `v.del` delete, `v.canDel`). `vSaved`/`vNot` = 1.5 s "Saved" flash after saving. `isUpload` = Data Policy Management. `hasNew` = a single create button (`{newL}` = its existing label: "New Profile", "New Policy", "Add New", "Create Account"). `isAppNew` = Application Management's **Add New** dropdown: `newItems` = your existing items (`n.t`, `n.d`, `n.isApps/isFeats/isActs` picks the icon); `itamOK` = your existing role check. The trigger's visible label is the app's ("Add New").

```html
<header class="lp-ph lp-rz" style="--d: 0">
  <span class="lp-bign" aria-hidden="true">{bign}</span>
  <div class="lp-ph-l">
    <p class="lp-eb">
      <b>{pn}</b><i></i>FMCES
    </p>
    <h1 class="lp-pt">{pTitle}</h1>
    <p class="lp-ps">
      <span>{pSub}</span>
      <!-- if hasSync -->
        <button type="button" class="{lp-sync [lp-busy]}" onClick={syncGo} title="Refresh now">
          <span class="lp-pulse"></span>{synced}
        </button>
      <!-- /if -->
    </p>
  </div>
  <div class="lp-pa">
    <!-- if hasView -->
      <div class="lp-anc">
        <button type="button" class="{lp-btn lp-btn-g [lp-on]}" onClick={viewGo} aria-haspopup="dialog" aria-expanded={viewOpen}>
          <Icon name="layers" size="16"/>Presets<span class="lp-sub">{viewT}</span><span class="lp-bdg">{viewN}</span><Icon name="chevron-down" size="14" bold/>
        </button>
        <!-- if viewOpen -->
          <div class="lp-pop" role="dialog" aria-label="Presets">
            <p class="lp-pop-h">
              <Icon name="layers" size="15"/>Presets
            </p>
            <div class="lp-pin2">
              <input type="text" ref={vnRef} value={viewName} onChange={onVn} onKeyDown={vnKey} placeholder="Name this preset…" aria-label="Preset name">
              <button type="button" class="lp-btn lp-btn-p lp-btn-sm" onClick={saveView}>
                <!-- if vNot -->
                  Save
                <!-- /if -->
                <!-- if vSaved -->
                  <Icon name="check" size="14" bold class="lp-okc"/>Saved
                <!-- /if -->
              </button>
            </div>
            <!-- for each v in views -->
              <div class="{lp-vw [lp-on]}" style="--i: {v.i}">
                <button type="button" class="lp-vw-b" onClick={v.pick}>
                  <span class="lp-grow"><span style="display: block">{v.n}</span><small>{v.sub}</small></span>
                </button>
                <button type="button" class="{lp-vwi [lp-on]}" onClick={v.star} aria-label={v.starL} title={v.starL}>
                  <Icon name="star" size="15"/>
                </button>
                <!-- if v.canDel -->
                  <button type="button" class="lp-vwi lp-del" onClick={v.del} aria-label={v.delL}>
                    <Icon name="trash" size="15"/>
                  </button>
                <!-- /if -->
              </div>
            <!-- /for -->
            <p class="lp-pnote">The starred preset opens when you come to this page.</p>
          </div>
        <!-- /if -->
      </div>
    <!-- /if -->
    <!-- if isUpload -->
      <button type="button" class="lp-btn lp-btn-g" onClick={upGo}>
        <Icon name="upload" size="16"/>Upload
      </button>
    <!-- /if -->
    <!-- if hasNew -->
      <button type="button" class="lp-btn lp-btn-p" onClick={newGo}>
        <Icon name="plus" size="16" bold class="lp-pl"/>{newL}
      </button>
    <!-- /if -->
    <!-- if isAppNew -->
      <div class="lp-anc">
        <button type="button" class="{lp-btn lp-btn-p [lp-on]}" onClick={newMenuGo} aria-haspopup="menu" aria-expanded={newOpen}>
          <Icon name="plus" size="16" bold class="lp-pl"/>New<Icon name="chevron-down" size="14" bold class="lp-chev2"/>
        </button>
        <!-- if newOpen -->
          <div class="lp-pop lp-nwm" role="menu" aria-label="Create">
            <p class="lp-pop-h">Create</p>
            <!-- for each n in newItems -->
              <button type="button" class="{lp-nwi [lp-on]}" role="menuitem" onClick={n.go} style="--i: {n.i}">
                <span class="lp-nwi-ic">
                <!-- if n.isApps -->
                  <Icon name="grid" size="17"/>
                <!-- /if -->
                <!-- if n.isFeats -->
                  <Icon name="box" size="17"/>
                <!-- /if -->
                <!-- if n.isActs -->
                  <Icon name="zap" size="17"/>
                <!-- /if -->
                </span><span class="lp-grow"><b>{n.t}</b><small>{n.d}</small></span>
              </button>
            <!-- /for -->
            <!-- if itamOK -->
              <div class="lp-nw-sep">
              </div>
              <button type="button" class="lp-nwi" role="menuitem" onClick={newItam} style="--i: 3">
                <span class="lp-nwi-ic"><Icon name="database" size="17"/></span><span class="lp-grow"><b>New ITAM record</b><small>Add an ITAM record</small></span>
              </button>
            <!-- /if -->
          </div>
        <!-- /if -->
      </div>
    <!-- /if -->
  </div>
</header>
```

## B.3 Application Management tabs

PROMPT §6.3. `amTabs` = the visible tabs in today's order (`t.t` name, `t.n` count [only if you have it], `t.sel`, `t.go`). `{amN}` = number of visible tabs. `{amX}` = `translateX(index × 100%)`.

```html
<!-- if isApp -->
  <div class="lp-gtw lp-rz" style="--d: 1">
    <nav class="lp-gt" style="--n: {amN}" role="tablist" aria-label="App Management sections">
      <span class="lp-ind" style="transform: {amX}"></span>
      <!-- for each t in amTabs -->
        <button type="button" role="tab" class="{[lp-on]}" aria-selected={t.sel} onClick={t.go}>{t.t}<em>{t.n}</em></button>
      <!-- /for -->
    </nav>
  </div>
<!-- /if -->
```

## B.4 List card: application band, card title, facts, toolbar, export menu, column chips, table, footer

PROMPT §6.2. `isScoped` = Features / Actions tabs (application band). `.lp-cdt` = the app's card title row ("Applications  22 total"). `facts` / `dist` = facts row + mix bar (`f.n` count, `f.t` label, `f.c` colour, `f.hasDot`). `{q}`, `{ph}`, `onQ` = your search; `{hitsT}` = "N matches". `fOn` / `{fT}` = active fact chip. **Your existing funnel filter button goes where the comment says, as `.lp-ibx`.** Extra toolbar buttons the app has (e.g. **Re-evaluate** on Entitlement Management) go right before Export as `lp-btn lp-btn-g` with their icon. `refGo` = existing refresh. Export: `{exN}` = "N rows · N cols". `colChips` = ALL columns in current order (`c.t`, `c.on`, `c.isOn`/`c.isOff`, `c.tog`; locked ones also get `lp-req`); `{colN}` = number of visible columns; `colChanged`/`colReset` only if a reset exists. The table block is YOUR table with the adapter classes. Footer: `{foot}` = the app's footer text; `pers` = 15 / 25 / 50; the page buttons stand for your pagination.

```html
<!-- if showList -->
  <section class="lp-cd lp-rz" style="--d: 2" aria-label={nouns}>
    <!-- if isScoped -->
      <div class="lp-scx">
        <div class="lp-scx-f">
          <span class="lp-scx-l" id="scl">Application</span>
          <div class="lp-anc lp-blk">
            <button type="button" class="{lp-scf [lp-on]}" onClick={scGo} aria-haspopup="dialog" aria-expanded={scExp} aria-labelledby="scl">
              <span class="lp-mgx">{scIni}</span><b>{scName}</b><Icon name="chevron-down" size="16" bold class="lp-chev"/>
            </button>
            <!-- if scOpen -->
              <div class="lp-pop lp-l lp-scp" role="dialog" aria-label="Choose an application">
                <label class="lp-psr">
                  <Icon name="search" size="15"/>
                  <input type="search" value={scQ} onChange={onScQ} placeholder="Search applications or ITAM" aria-label="Search applications or ITAM">
                </label>
                <p class="lp-pop-g">Applications</p>
                <div role="listbox" aria-label="Applications">
                  <!-- for each o in scOpts -->
                    <button type="button" class="{lp-opt [lp-on]}" role="option" aria-selected={o.on} onClick={o.go} style="--i: {o.i}">
                      <span class="{lp-mgx [lp-dr]}">{o.ini}</span><span class="lp-grow"><b>{o.t}</b><small>{o.m}</small></span><span class="{lp-lc lp-lc-live|lp-lc-draft|lp-lc-pend|lp-lc-rev|lp-lc-err|lp-lc-off}"><i></i></span>
                      <!-- if o.on -->
                        <span class="lp-ok"><Icon name="check" size="16" bold/></span>
                      <!-- /if -->
                    </button>
                  <!-- /for -->
                </div>
                <!-- if scNone -->
                  <p class="lp-pnote">No application matches “{scQ}”.</p>
                <!-- /if -->
              </div>
            <!-- /if -->
          </div>
        </div>
        <div class="lp-scx-m">
          <span class="lp-kv3"><small>App UID</small><b>{scUid}</b></span><span class="lp-kv3"><small>ITAM</small><b>{scItam}</b></span><span class="lp-kv3"><small>Status</small><span class="{lp-lc lp-lc-live|lp-lc-draft|lp-lc-pend|lp-lc-rev|lp-lc-err|lp-lc-off}"><i></i><span class="lp-lct">{scLcT}</span></span></span>
        </div>
        <p class="lp-scx-n">{scNote}</p>
      </div>
    <!-- /if -->
    <!-- the app's card title, e.g. "Applications  22 total" -->
    <div class="lp-cdt"><span>{the app's card title}</span><small>{N} total</small></div>
    <div class="lp-cd-h">
      <div class="lp-fx">
        <div class="lp-fx-r" role="group" aria-label="Filter by status">
          <!-- for each f in facts -->
            <button type="button" class="{lp-fb [lp-on] [lp-zero]}" onClick={f.pick}>
              <span class="lp-fb-n">{f.n}</span><span class="lp-fb-l">
              <!-- if f.hasDot -->
                <i class="lp-fb-d" style="--c: {f.c}"></i>
              <!-- /if -->
              {f.t}</span>
            </button>
          <!-- /for -->
        </div>
        <div class="lp-dist" aria-hidden="true">
          <!-- for each d in dist -->
            <i style="--c: {d.c}; --w: {d.w}; --k: {d.k}"></i>
          <!-- /for -->
        </div>
      </div>
      <div class="lp-tl">
        <label class="lp-sr">
          <Icon name="search" size="16"/>
          <input type="search" ref={srRef} value={q} onChange={onQ} placeholder={ph} aria-label={ph}>
          <!-- if hasQ -->
            <span class="lp-hits">{hitsT}</span>
          <!-- /if -->
          <!-- if hasQ -->
            <button type="button" class="lp-x" onClick={clearQ} aria-label="Clear search">
              <Icon name="close" size="12" bold/>
            </button>
          <!-- /if -->
          <!-- if noQ -->
            <kbd>/</kbd>
          <!-- /if -->
        </label>
        <!-- if fOn -->
          <span class="lp-fchip">{fT}
          <button type="button" onClick={fClear} aria-label="Clear the filter">
            <Icon name="close" size="12" bold/>
          </button>
          </span>
        <!-- /if -->
        <span class="lp-tsep"></span>
        <button type="button" class="{lp-ibx [lp-spin]}" onClick={refGo} aria-label="Refresh" title="Refresh">
          <Icon name="refresh" size="17"/>
        </button>
        <div class="lp-anc">
          <button type="button" class="{lp-btn lp-btn-g [lp-on] [lp-ok]}" onClick={exGo} aria-haspopup="menu" aria-expanded={exOpen}>
            <!-- if exNot -->
              <Icon name="download" size="16" class="lp-dl"/>Export<Icon name="chevron-down" size="14" bold class="lp-chev2"/>
            <!-- /if -->
            <!-- if exDone -->
              <Icon name="check" size="16" bold class="lp-okc"/>Exported
            <!-- /if -->
          </button>
          <!-- if exOpen -->
            <div class="lp-pop" role="menu" aria-label="Export">
              <p class="lp-pop-h">Export<span class="lp-mono">{exN}</span></p>
              <button type="button" class="lp-xi" role="menuitem" onClick={exCsv}>
                <span class="lp-ft lp-csv">CSV</span><span><b>CSV</b><small>Comma-separated values</small></span>
              </button>
              <button type="button" class="lp-xi" role="menuitem" onClick={exXls}>
                <span class="lp-ft lp-xls">XLSX</span><span><b>Excel</b><small>Microsoft Excel (.xlsx)</small></span>
              </button>
              <p class="lp-pnote">Only the rows and columns you can see are exported.</p>
            </div>
          <!-- /if -->
        </div>
      </div>
    </div>
    <div class="lp-colbar" role="group" aria-label="Columns">
      <span class="lp-colbar-l"><Icon name="columns" size="14"/>Columns<b>{colN}</b></span>
      <!-- for each c in colChips -->
        <button type="button" class="{lp-cch [lp-on]}" role="checkbox" aria-checked={c.on} onClick={c.tog} style="--i: {c.i}">
          <span class="lp-cc">
          <!-- if c.isOn -->
            <Icon name="check" size="11" bold/>
          <!-- /if -->
          <!-- if c.isOff -->
            <Icon name="plus" size="11" bold/>
          <!-- /if -->
          </span>{c.t}
        </button>
      <!-- /for -->
      <!-- if colChanged -->
        <button type="button" class="lp-lk lp-colrs" onClick={colReset}>
          <Icon name="refresh" size="13"/>Reset
        </button>
      <!-- /if -->
    </div>
    <!-- YOUR EXISTING TABLE COMPONENT, with the adapter classes (section 6.4). Native elements shown; use your library's equivalents. -->
    <div class="{lp-xt-wrap [lp-slr1|lp-slr2|lp-sll1|lp-sll2]}">
      <table class="{lp-xt lp-xt-click [lp-cf1|lp-cf2] [lp-resizing]}" aria-label={nouns}>
        <thead>
          <tr>
            <th class="lp-xt-th" title="Pinned rows stay on top"><Icon name="pin" size="14"/><span class="lp-sr-only">Pin</span></th>
            <th class="lp-xt-th lp-xt-num">#</th>
            <!-- for each h in your visible columns, in your order -->
              <th class="{lp-xt-th [lp-on] [lp-desc] [lp-drag] [lp-drop-l|lp-drop-r]}" aria-sort={h.ariaSort} draggable={your existing drag setting} style="width: {your existing width}">
                <!-- your existing sort click target -->{h.title}<Icon name="arrow-up" size="13" bold class="lp-sa"/>
                <span class="{lp-xt-rz [lp-on]}" aria-hidden="true"><!-- your existing resize handle + handlers --></span>
              </th>
            <!-- /for -->
            <th class="lp-xt-th lp-xt-act"><span class="lp-sr-only">Edit</span></th>
          </tr>
        </thead>
        <!-- if loading -->
          <tbody>
            <tr>
              <td class="lp-xt-grp" colspan={all columns}>
                <!-- SKELETON (B.6) -->
              </td>
            </tr>
          </tbody>
        <!-- /if -->
        <!-- if showRows -->
          <tbody class="{lp-xt-body [lp-lb]}">
            <!-- if pinned rows are grouped at the top today -->
              <tr>
                <td class="lp-xt-grp" colspan={all columns}>
                  <div class="lp-tgr"><Icon name="pin" size="13"/>Pinned <b>{pinnedCount}</b></div>
                </td>
              </tr>
              <!-- TABLE ROW (B.5), once for each pinned row -->
              <tr>
                <td class="lp-xt-grp" colspan={all columns}>
                  <div class="lp-tgr">{label for the other rows, e.g. "All {nouns}"}</div>
                </td>
              </tr>
            <!-- /if -->
            <!-- TABLE ROW (B.5), once for each row on this page -->
          </tbody>
        <!-- /if -->
        <!-- if empty -->
          <tbody>
            <tr>
              <td class="lp-xt-grp" colspan={all columns}>
                <div class="lp-emp">
                  <span class="lp-emp-ic"><Icon name="search" size="22"/></span>
                  <p class="lp-emp-t">{the app's empty title}</p>
                  <p class="lp-emp-s">{the app's empty sentence}</p>
                  <!-- if the emptiness comes from a search or a fact filter -->
                    <button type="button" class="lp-btn lp-btn-g lp-btn-sm" onClick={clearSearchOrFilter}>{Clear search | Show all}</button>
                  <!-- /if -->
                </div>
              </td>
            </tr>
          </tbody>
        <!-- /if -->
      </table>
    </div>
    <div class="lp-tf">
      <span>{foot}</span><span class="lp-grow"></span><span>Rows per page</span>
      <div class="lp-seg" role="group" aria-label="Rows per page">
        <!-- for each p in pers -->
          <button type="button" class="{[lp-on]}" onClick={p.go}>{p.t}</button>
        <!-- /for -->
      </div>
      <div class="lp-pgr">
        <button type="button" class="lp-pgb2 lp-dis" aria-label="Previous page">
          <Icon name="chevron-left" size="15"/>
        </button>
        <button type="button" class="lp-pgb2 lp-on" aria-current="page">1</button>
        <button type="button" class="lp-pgb2 lp-dis" aria-label="Next page">
          <Icon name="chevron-right" size="15"/>
        </button>
      </div>
    </div>
  </section>
<!-- /if -->
```

## B.5 Table row and cell contents (adapter)

PROMPT §6.4–6.5. One body row of your table. Each column gets exactly ONE of the cell contents shown, by type. The pencil cell is always rendered; the CSS hides the pencil until the row is hovered or focused.

```html
<!-- One body row of YOUR table. Keep your row click (opens the drawer) and your existing cell renderers' values. -->
<tr class="{lp-xt-r [lp-sel] [lp-pinned] [lp-flash]}" style="--i: {index on this page}" data-k={record id} onClick={your existing open-drawer handler}>
  <td class="lp-xt-td">
    <button type="button" class="{lp-pin [lp-on]}" onClick={your existing pin handler (stops propagation)} aria-pressed={isPinned} aria-label={Pin | Unpin} title={Pin | Unpin}>
      <Icon name="pin" size="15"/>
    </button>
  </td>
  <td class="lp-xt-td lp-xt-num">{row number}</td>
  <!-- for each c in your visible columns: ONE of the cell contents below, chosen by column type (section 6.5) -->
    <td class="lp-xt-td" title={full text value}>
      <!-- PRIMARY NAME column -->
        <span class="lp-nmb">
          <span class="{lp-mgx [lp-dr|lp-pd|lp-rv|lp-rj] [lp-sv]}" aria-hidden="true">{initials} <!-- or <Icon name="user" size="15"/> / <Icon name="server" size="15"/> for accounts --></span>
          <span class="{lp-nmt [lp-mono]}">{name} <!-- client-side search: {before}<mark>{match}</mark>{after} --></span>
        </span>
      <!-- IDS, CODES, OWNERS, CII NUMBER, DLs -->
        <span class="lp-tt lp-mono">{value}</span>
      <!-- PLAIN TEXT / DESCRIPTION -->
        <span class="lp-tt">{value}</span>
      <!-- EMPTY VALUE (keep the app's marker, e.g. "—") -->
        <span class="lp-tt lp-dim">{empty marker}</span>
      <!-- STATUS -->
        <span class="{lp-lc lp-lc-live|lp-lc-draft|lp-lc-pend|lp-lc-rev|lp-lc-err|lp-lc-off}"><i></i><span class="lp-lct">{the app's status word}</span>
          <!-- if the app shows a newer draft next to an approved version --><span class="lp-lc-x">{the app's text, e.g. v3 draft}</span><!-- /if -->
        </span>
      <!-- ACTIVE / ENABLED -->
        <span class="{lp-st [lp-off]}"><i></i>{the app's word}</span>
      <!-- VERSION -->
        <span class="lp-vr">{version}</span>
      <!-- COUNT -->
        <span class="lp-cn"><b class="{[lp-z]}">{count}</b></span>
      <!-- DATE (Onboard Date, Last modified, Created…) -->
        <span class="lp-dt"><b>{date, formatted exactly as today}</b><small>{relative, e.g. 3 days ago}</small></span>
      <!-- OLA -->
        <button type="button" class="lp-ola" onClick={your existing OLA handler (stops propagation)} aria-label={the app's OLA label} title={the app's OLA label}>
          <Icon name="doc" size="16"/>
        </button>
      <!-- CHIP(S): application names, roles -->
        <span class="lp-chps"><span class="lp-chp">{value}</span><span class="lp-chp">{value}</span></span>
      <!-- TYPE (User / Service) -->
        <span class="lp-ty"><Icon name="user" size="15"/>{the app's word}</span>
      <!-- YES / NO FLAG -->
        <span class="{lp-yn [lp-y]}">{the app's word}</span>
    </td>
  <!-- /for -->
  <td class="lp-xt-td lp-xt-act">
    <button type="button" class="lp-rab" onClick={your existing edit handler (stops propagation)} aria-label={Edit {name}} title="Edit">
      <Icon name="pencil" size="15"/>
    </button>
  </td>
</tr>
```

## B.6 Loading skeleton

Six rows; `k.w` = 55%, 57%, 59%, 61%, 63%, 65% (row 0 to 5).

```html
<div aria-hidden="true">
  <!-- for each k in sk -->
    <div class="lp-skr">
      <span class="lp-sk" style="width: 16px"></span><span class="lp-sk lp-av"></span><span class="lp-sk" style="width: {k.w}"></span><span class="lp-sk"></span><span class="lp-sk" style="width: 70%"></span><span class="lp-sk" style="width: 60%"></span><span class="lp-sk" style="width: 50%"></span>
    </div>
  <!-- /for -->
</div>
```

## B.7 Upload dialog (Data Policy Management)

PROMPT §6.6. `{upPT}` = size / status text. `{upBtnT}` = the app's upload button label. `upBusy` / `{upP}` = upload progress, only if you have it. If your modal portals to `<body>`, wrap it in its own `<div class="lp-root">`.

```html
<!-- if upOpen -->
  <div class="lp-dw">
    <button type="button" class="lp-dscrim" aria-label="Close" onClick={upClose}>
    </button>
    <section class="lp-dlg" role="dialog" aria-modal="true" aria-label="Upload data policies">
      <div class="lp-dlg-h">
        <span class="lp-dlg-ic"><Icon name="upload" size="20"/></span>
        <div>
          <h2>Upload data policies</h2>
          <p>Add or update many policies at once from an Excel file.</p>
        </div>
        <button type="button" class="lp-xclose" onClick={upClose} aria-label="Close">
          <Icon name="close" size="18"/>
        </button>
      </div>
      <div class="lp-dlg-b">
        <div class="lp-steps">
          <div class="lp-stp">
            <span class="lp-stp-n lp-ok">1</span>
            <div class="lp-grow">
              <b>Download the template</b><small>Keep its column headings as they are.</small>
            </div>
            <button type="button" class="lp-lk" onClick={tplGo}>
              <Icon name="download" size="14"/>{template file name}
            </button>
          </div>
          <div class="lp-stp">
            <span class="lp-stp-n lp-ok">2</span>
            <div class="lp-grow">
              <b>Fill in one policy per row</b><small>Each row becomes one policy. Save the file as .xlsx.</small>
            </div>
          </div>
          <div class="lp-stp">
            <span class="{lp-stp-n [lp-ok]}">3</span>
            <div class="lp-grow">
              <b>Upload it here</b>
              <!-- if upNoFile -->
                <button type="button" class="lp-drop" onClick={upPick}>
                  <span class="lp-drop-ic"><Icon name="upload" size="22"/></span><b>Drop your Excel file here</b><small>or <span class="lp-u">browse your computer</span> · .xlsx only</small>
                </button>
              <!-- /if -->
              <!-- if upHasFile -->
                <div class="lp-fil">
                  <span class="lp-ft lp-xls">XLSX</span>
                  <div class="lp-grow">
                    <b>{file name}</b><small>{upPT}</small>
                    <!-- if upBusy -->
                      <div class="lp-prog">
                        <i style="--p: {upP}"></i>
                      </div>
                    <!-- /if -->
                  </div>
                  <button type="button" class="lp-xclose" style="align-self: center" onClick={upRm} aria-label="Remove file">
                    <Icon name="close" size="16"/>
                  </button>
                </div>
              <!-- /if -->
            </div>
          </div>
        </div>
      </div>
      <div class="lp-dlg-f">
        <button type="button" class="lp-btn lp-btn-g" onClick={upClose}>Cancel</button>
        <button type="button" class="{lp-btn lp-btn-p [lp-dis]}" onClick={upGo}>
          <Icon name="upload" size="16" bold/>{upBtnT}
        </button>
      </div>
    </section>
  </div>
<!-- /if -->
```

## B.8 Entitlement Users: finder, start state, tabs, context card

PROMPT §6.7. `uItams` / `uApps` = your ITAM and application options (`o.t`, `o.m`, `o.on`, `o.go`). `{uItamT}` / `{uAppT}` = the chosen value or the app's placeholder ("Select ITAM", "Select ITAM first"). `uQ` / `uSearch` = your quick search. `uStart` / `uLoading` / `uLoaded` = states. `uTabs` = Accounts / Entitlements with counts; `{uX}` = indicator transform. `ghost` = 4 decorative rows (`g.i` 0–3; `g.w1` 62%, 48%, 70%, 54%; `g.w2` 34%, 40%, 28%, 36%) — the same ghost rows are used on Reports and FMID Reports. After this block, render the list card (B.4) for the active tab.

```html
<!-- if isUsers -->
  <section class="lp-fnd2 lp-rz" style="--d: 1" role="search" aria-label="Find user accounts">
    <div class="lp-fz">
      <p class="lp-fz-h">
        <span class="lp-fz-ic"><Icon name="grid" size="17"/></span><span><b>Browse by application</b><small>Pick the ITAM, then one of its applications.</small></span>
      </p>
      <div class="lp-fz-row">
        <div class="lp-anc lp-blk">
          <button type="button" class="{lp-sel2 [lp-on]}" onClick={uItamGo} aria-haspopup="listbox" aria-expanded={uItamOpen}>
            <span class="{lp-sel2-n [lp-ok]}">1</span><span><small>ITAM</small><b class="{[lp-ph]}">{uItamT}</b></span><Icon name="chevron-down" size="16" bold class="lp-chev"/>
          </button>
          <!-- if uItamOpen -->
            <div class="lp-pop lp-l" role="listbox" aria-label="ITAM">
              <!-- for each o in uItams -->
                <button type="button" class="{lp-opt [lp-on]}" role="option" aria-selected={o.on} onClick={o.go} style="--i: {o.i}">
                  <span class="lp-grow"><b>{o.t}</b>
                  <!-- if o.m -->
                    <small>{o.m}</small>
                  <!-- /if -->
                  </span>
                  <!-- if o.on -->
                    <span class="lp-ok"><Icon name="check" size="16" bold/></span>
                  <!-- /if -->
                </button>
              <!-- /for -->
            </div>
          <!-- /if -->
        </div>
        <span class="lp-fz-ln" aria-hidden="true"><Icon name="chevron-right" size="16"/></span>
        <div class="lp-anc lp-blk">
          <button type="button" class="{lp-sel2 [lp-on] [lp-dis]}" onClick={uAppGo} aria-haspopup="listbox" aria-expanded={uAppOpen}>
            <span class="{lp-sel2-n [lp-ok]}">2</span><span><small>Application</small><b class="{[lp-ph]}">{uAppT}</b></span><Icon name="chevron-down" size="16" bold class="lp-chev"/>
          </button>
          <!-- if uAppOpen -->
            <div class="lp-pop lp-l" role="listbox" aria-label="Application">
              <!-- for each o in uApps -->
                <button type="button" class="{lp-opt [lp-on]}" role="option" aria-selected={o.on} onClick={o.go} style="--i: {o.i}">
                  <span class="lp-grow"><b>{o.t}</b>
                  <!-- if o.m -->
                    <small>{o.m}</small>
                  <!-- /if -->
                  </span>
                  <!-- if o.on -->
                    <span class="lp-ok"><Icon name="check" size="16" bold/></span>
                  <!-- /if -->
                </button>
              <!-- /for -->
            </div>
          <!-- /if -->
        </div>
      </div>
    </div>
    <div class="lp-fz-or" aria-hidden="true">
      <span>or</span>
    </div>
    <div class="lp-fz">
      <p class="lp-fz-h">
        <span class="lp-fz-ic"><Icon name="search" size="17"/></span><span><b>Find one person</b><small>Search by owner or account name across every ITAM.</small></span>
      </p>
      <label class="lp-qs">
        <Icon name="search" size="17"/>
        <input type="search" value={uQ} onChange={onUQ} onKeyDown={uQKey} placeholder="Owner or account name" aria-label="Search accounts across all ITAMs">
        <button type="button" class="lp-btn lp-btn-p lp-btn-sm" onClick={uSearch}>Search</button>
      </label>
    </div>
  </section>
  <!-- if uLoaded -->
    <div class="lp-gtw lp-rz" style="--d: 2">
      <nav class="lp-gt" style="--n: 2" role="tablist" aria-label="Accounts or entitlements">
        <span class="lp-ind" style="transform: {uX}"></span>
        <!-- for each t in uTabs -->
          <button type="button" role="tab" class="{[lp-on]}" onClick={t.go}>{t.t}<em>{t.n}</em></button>
        <!-- /for -->
      </nav>
      <!-- if uCtxApp -->
        <span class="lp-ctx"><span class="lp-mgx">{uCtxIni}</span><span><b>{uCtxName}</b><small>{uCtxMeta}</small></span></span>
      <!-- /if -->
      <!-- if uCtxCross -->
        <span class="lp-ctx"><span class="lp-mgx"><Icon name="search" size="15"/></span><span><b>Results for “{uCtxQ}”</b><small>across all ITAMs</small></span></span>
      <!-- /if -->
    </div>
  <!-- /if -->
  <!-- if uStart -->
    <div class="lp-hero0 lp-rz" style="--d: 2">
      <div class="lp-ghost" aria-hidden="true">
        <!-- for each g in ghost -->
          <div class="lp-gh-r" style="--i: {g.i}">
            <span class="lp-gh-av"></span><span class="lp-gh-l" style="width: {g.w1}"></span><span class="lp-gh-l lp-s" style="width: {g.w2}"></span><span class="lp-gh-p"></span>
          </div>
        <!-- /for -->
      </div>
      <p class="lp-hero0-t">Pick an ITAM and an application to see who has access.</p>
      <p class="lp-hero0-s">Accounts and the entitlements they hold load as soon as you choose the application.</p>
    </div>
  <!-- /if -->
  <!-- if uLoading -->
    <section class="lp-cd" aria-label="Loading accounts">
      <div class="lp-cd-h">
        <span class="lp-sk" style="width: 260px; height: 30px"></span>
      </div>
      <div aria-hidden="true">
        <!-- for each k in sk -->
          <div class="lp-skr">
            <span class="lp-sk" style="width: 16px"></span><span class="lp-sk lp-av"></span><span class="lp-sk" style="width: {k.w}"></span><span class="lp-sk"></span><span class="lp-sk" style="width: 70%"></span><span class="lp-sk" style="width: 60%"></span><span class="lp-sk" style="width: 50%"></span>
          </div>
        <!-- /for -->
      </div>
    </section>
  <!-- /if -->
<!-- /if -->
```

## B.9 Reports

PROMPT §6.8. `rApps` = your applications; `{rAppT}` = chosen app or the app's placeholder ("Select application…", "Loading applications…" while loading). `rFields` / `{rFN}` = your field toggles (Account Name, Account Owner, Account Type, Account Status, Is Privileged, Application) and the selected count. `rFmtCards` = CSV / Excel / JSON (`f.fs` badge text CSV / XLSX / JSON, `f.t`, `f.d`). `rPrevGo` = Generate Preview, `rDlGo` / `{rDlT}` = Download Report. `rEmpty` / `rBusy` / `rGen` = before / generating / generated. `{rFt}` / `{rFile}` = format badge and file name (omit if you don't have a name); `{rMetaN}` / `{rMetaF}` = "N accounts" / "N fields". `rQ` = your results search.

```html
<!-- if isReports -->
  <div class="lp-rb lp-rz" style="--d: 1">
    <aside class="lp-rp" aria-label="Report settings">
      <div class="lp-rs2">
        <span class="{lp-rs2-n [lp-ok]}">1</span>
        <div class="lp-rs2-b">
          <p class="lp-rs2-t">Application</p>
          <div class="lp-anc lp-blk">
            <button type="button" class="{lp-sel2 [lp-on]}" onClick={rAppGo} aria-haspopup="listbox" aria-expanded={rAppOpen}>
              <span><small>Accounts of</small><b class="{[lp-ph]}">{rAppT}</b></span><Icon name="chevron-down" size="16" bold class="lp-chev"/>
            </button>
            <!-- if rAppOpen -->
              <div class="lp-pop lp-l" role="listbox" aria-label="Accounts of" style="width: 100%">
                <!-- for each o in rApps -->
                  <button type="button" class="{lp-opt [lp-on]}" role="option" aria-selected={o.on} onClick={o.go} style="--i: {o.i}">
                    <span class="lp-grow"><b>{o.t}</b>
                    <!-- if o.m -->
                      <small>{o.m}</small>
                    <!-- /if -->
                    </span>
                    <!-- if o.on -->
                      <span class="lp-ok"><Icon name="check" size="16" bold/></span>
                    <!-- /if -->
                  </button>
                <!-- /for -->
              </div>
            <!-- /if -->
          </div>
        </div>
      </div>
      <div class="lp-rs2">
        <span class="lp-rs2-n lp-ok">2</span>
        <div class="lp-rs2-b">
          <p class="lp-rs2-t">
            Fields<span class="lp-mono">{rFN}</span>
            <!-- if rAllOff -->
              <button type="button" class="lp-lk" onClick={rAllF}>Select all</button>
            <!-- /if -->
          </p>
          <div class="lp-tgl">
            <!-- for each f in rFields -->
              <button type="button" class="{lp-tg [lp-on]}" aria-pressed={f.on} onClick={f.go}>
                <span class="lp-ckb"><Icon name="check" size="11" bold/></span>{f.t}
              </button>
            <!-- /for -->
          </div>
        </div>
      </div>
      <div class="lp-rs2 lp-end">
        <span class="lp-rs2-n lp-ok">3</span>
        <div class="lp-rs2-b">
          <p class="lp-rs2-t">Format</p>
          <div class="lp-fmts" role="radiogroup" aria-label="File format">
            <!-- for each f in rFmtCards -->
              <button type="button" class="{lp-fmt [lp-on]}" role="radio" aria-checked={f.on} onClick={f.go}>
                <span class="{lp-ft lp-csv|lp-xls|lp-json}">{f.fs}</span><b>{f.t}</b><small>{f.d}</small>
              </button>
            <!-- /for -->
          </div>
        </div>
      </div>
      <div class="lp-rp-f">
        <button type="button" class="lp-btn lp-btn-g" onClick={rPrevGo}>
          <Icon name="eye" size="16"/>Preview report
        </button>
        <button type="button" class="{lp-btn lp-btn-p [lp-dis]}" onClick={rDlGo}>
          <Icon name="download" size="16" bold class="lp-dl"/>{rDlT}
        </button>
      </div>
    </aside>
    <section class="lp-cd lp-rv" style="margin-top: 0" aria-label="Report preview">
      <!-- if rEmpty -->
        <div class="lp-hero0" style="padding: 70px 20px 80px">
          <div class="lp-ghost" aria-hidden="true">
            <!-- for each g in ghost -->
              <div class="lp-gh-r" style="--i: {g.i}">
                <span class="lp-gh-av"></span><span class="lp-gh-l" style="width: {g.w1}"></span><span class="lp-gh-l lp-s" style="width: {g.w2}"></span><span class="lp-gh-p"></span>
              </div>
            <!-- /for -->
          </div>
          <p class="lp-hero0-t" style="font-size: 24px">Your report preview appears here</p>
          <p class="lp-hero0-s">Pick an application and the fields you need, then preview it before you download.</p>
        </div>
      <!-- /if -->
      <!-- if rBusy -->
        <div class="lp-rv-h">
          <span class="lp-sk" style="width: 220px; height: 16px"></span>
        </div>
        <div aria-hidden="true">
          <!-- for each k in sk -->
            <div class="lp-skr">
              <span class="lp-sk" style="width: 16px"></span><span class="lp-sk lp-av"></span><span class="lp-sk" style="width: {k.w}"></span><span class="lp-sk"></span><span class="lp-sk" style="width: 70%"></span><span class="lp-sk" style="width: 60%"></span><span class="lp-sk" style="width: 50%"></span>
            </div>
          <!-- /for -->
        </div>
      <!-- /if -->
      <!-- if rGen -->
        <div class="lp-doc-h">
          <span class="lp-doc-tab"><span class="{lp-ft lp-csv|lp-xls|lp-json}">{rFt}</span><b>{rFile}</b></span><span class="lp-kv3"><b>{rMetaN}</b></span><span class="lp-kv3"><b>{rMetaF}</b></span><span class="lp-grow"></span>
          <label class="lp-sr" style="width: 240px">
            <Icon name="search" size="16"/>
            <input type="search" value={rQ} onChange={onRQ} placeholder="Search the report" aria-label="Search the report">
          </label>
        </div>
        <!-- YOUR EXISTING results table, with the adapter classes (section 6.4) -->
        <div class="lp-xt-wrap">
          <table class="lp-xt" aria-label="Report preview">
            <thead>
              <tr>
                <th class="lp-xt-th lp-xt-num">#</th>
                <!-- for each h in your existing columns -->
                  <th class="lp-xt-th">{h.title}</th>
                <!-- /for -->
              </tr>
            </thead>
            <tbody class="{lp-xt-body [lp-lb]}">
              <!-- for each r in the rows you show today -->
                <tr class="lp-xt-r" style="--i: {index}">
                  <td class="lp-xt-td lp-xt-num">{row number}</td>
                  <!-- for each c in r's cells -->
                    <td class="lp-xt-td" title={value}><span class="{lp-tt [lp-mono]}">{value}</span></td>
                  <!-- /for -->
                </tr>
              <!-- /for -->
            </tbody>
          </table>
          <!-- if no rows -->
            <div class="lp-emp">
              <p class="lp-emp-t">{the app's no-results text}</p>
            </div>
          <!-- /if -->
        </div>
        <!-- if rMore -->
          <div class="lp-more">
            <span>{the app's "Showing 10 of 20"}</span><button type="button" class="lp-btn lp-btn-g lp-btn-sm" onClick={your Show 10 more handler}>Show 10 more</button><button type="button" class="lp-btn lp-btn-g lp-btn-sm" onClick={your Show all handler}>Show all</button>
          </div>
        <!-- /if -->
      <!-- /if -->
    </section>
  </div>
<!-- /if -->
```

## B.10 FMID Reports

PROMPT §6.9. `pItams` / `pApps` = your ITAM ID and Application options. `pModes` = All Users / Specific IDs, `{pMX}` = indicator transform, `pSpecific` = IDs input shown. `pFetch` / `{pFetchT}` = "Fetch Report (All Users)" (the app's label); `pReset` = Reset (add Clear all next to it, same style, if the app has it); `{pHint}` = "All users for the selected Application will be fetched in one request." `{pAppName}`; `{pXFmt}` = render your existing format select ("Excel (.xlsx)") here as `select.lp-mini`; `mxGo` = Download Security Matrix. The card title is the app's "Functional Entitlement Security Matrix". `pIdle` / `pFetching` / `pDone` = states. `pSteps` / `{pP}` only if real progress exists. Results: `{pUsers}` / `{pUsersL}` = number + label; the `.lp-kv3` pills stand for your result chips; `pViews` = Detail / Matrix, `{pVX}` = indicator transform; `pCsv` / `pXls` / `pJson` = your exports. Filters: one `.lp-ddg` per existing filter, each with its `.lp-inf` info trigger wired to your existing tooltip. `{pCount}` = the app's counts line. `pGroups` = your COLUMNS groups. The table block is your Detail table — and, the same way, your Matrix table with ALL its columns.

```html
<!-- if isReport -->
  <div class="lp-pgrid lp-rz" style="--d: 1">
    <section class="lp-prm" aria-label="Search parameters">
      <p class="lp-prm-h">Search parameters</p>
      <div class="lp-prm-r">
        <div class="lp-fld">
          <small><span class="lp-sel2-n lp-ok">1</span>ITAM ID<span class="lp-req-star">*</span></small>
          <div class="lp-anc">
            <button type="button" class="{lp-sel2 [lp-on]}" onClick={pItamGo} aria-haspopup="listbox" aria-expanded={pItamOpen}>
              <span><small class="lp-sr-only">ITAM</small><b class="{pItamPh}">{pItamT}</b></span><Icon name="chevron-down" size="16" bold class="lp-chev"/>
            </button>
            <!-- if pItamOpen -->
              <div class="lp-pop lp-l" role="listbox" aria-label="ITAM" style="width: 280px">
                <!-- for each o in pItams -->
                  <button type="button" class="{lp-opt [lp-on]}" role="option" aria-selected={o.on} onClick={o.go} style="--i: {o.i}">
                    <span class="lp-grow"><b>{o.t}</b>
                    <!-- if o.m -->
                      <small>{o.m}</small>
                    <!-- /if -->
                    </span>
                    <!-- if o.on -->
                      <span class="lp-ok"><Icon name="check" size="16" bold/></span>
                    <!-- /if -->
                  </button>
                <!-- /for -->
              </div>
            <!-- /if -->
          </div>
        </div>
        <span class="lp-fz-ln lp-prm-ln" aria-hidden="true"><Icon name="chevron-right" size="16"/></span>
        <div class="lp-fld">
          <small><span class="lp-sel2-n lp-ok">2</span>Application<span class="lp-req-star">*</span></small>
          <div class="lp-anc">
            <button type="button" class="{lp-sel2 [lp-on]}" onClick={pAppGo} aria-haspopup="listbox" aria-expanded={pAppOpen}>
              <span><small class="lp-sr-only">Application</small><b class="{pAppPh}">{pAppT}</b></span><Icon name="chevron-down" size="16" bold class="lp-chev"/>
            </button>
            <!-- if pAppOpen -->
              <div class="lp-pop lp-l" role="listbox" aria-label="Application" style="width: 280px">
                <!-- for each o in pApps -->
                  <button type="button" class="{lp-opt [lp-on]}" role="option" aria-selected={o.on} onClick={o.go} style="--i: {o.i}">
                    <span class="lp-grow"><b>{o.t}</b>
                    <!-- if o.m -->
                      <small>{o.m}</small>
                    <!-- /if -->
                    </span>
                    <!-- if o.on -->
                      <span class="lp-ok"><Icon name="check" size="16" bold/></span>
                    <!-- /if -->
                  </button>
                <!-- /for -->
              </div>
            <!-- /if -->
          </div>
        </div>
        <span class="lp-fz-ln lp-prm-ln" aria-hidden="true"><Icon name="chevron-right" size="16"/></span>
        <div class="lp-fld">
          <small><span class="lp-sel2-n lp-ok">3</span>Bank ID(s)<span class="lp-req-star">*</span></small>
          <div class="lp-bseg" role="group" aria-label="Bank IDs">
            <span class="lp-ind" style="transform: {pMX}"></span>
            <!-- for each m in pModes -->
              <button type="button" class="{[lp-on]}" onClick={m.go}>{m.t}</button>
            <!-- /for -->
          </div>
        </div>
      </div>
      <!-- if pSpecific -->
        <div class="lp-ids">
          <textarea value={pIds} onChange={onPIds} placeholder="1000412, 1000587" aria-label="Bank IDs">
          </textarea>
          <small>Paste Bank IDs separated by commas, spaces or new lines.</small>
        </div>
      <!-- /if -->
      <div class="lp-prm-f">
        <button type="button" class="{lp-btn lp-btn-p [lp-dis]}" onClick={pFetch}>
          <Icon name="arrow-right" size="16" bold/>{pFetchT}
        </button>
        <button type="button" class="lp-btn lp-btn-g" onClick={pReset}>Reset</button>
        <span class="lp-hintx">{pHint}</span>
      </div>
    </section>
    <aside class="lp-mxk" aria-label="Security matrix">
      <span class="lp-ft lp-xls">XLSX</span>
      <p class="lp-mxk-t">Security matrix</p>
      <p class="lp-mxk-s">The functional entitlement security matrix for {pAppName}.</p>
      <div class="lp-mxk-f">
        <span class="lp-mini">{pXFmt}</span>
        <button type="button" class="lp-btn lp-btn-g lp-btn-sm" onClick={mxGo}>
          <Icon name="download" size="15" class="lp-dl"/>Download
        </button>
      </div>
    </aside>
  </div>
  <!-- if pIdle -->
    <div class="lp-hero0 lp-rz" style="--d: 2; padding: 56px 20px 70px">
      <div class="lp-ghost" aria-hidden="true">
        <!-- for each g in ghost -->
          <div class="lp-gh-r" style="--i: {g.i}">
            <span class="lp-gh-av"></span><span class="lp-gh-l" style="width: {g.w1}"></span><span class="lp-gh-l lp-s" style="width: {g.w2}"></span><span class="lp-gh-p"></span>
          </div>
        <!-- /for -->
      </div>
      <p class="lp-hero0-t" style="font-size: 24px">Nothing fetched yet</p>
      <p class="lp-hero0-s">Choose the ITAM, the application and whose Bank IDs to include, then fetch. Large applications can take a moment.</p>
    </div>
  <!-- /if -->
  <!-- if pFetching -->
    <div class="lp-fet" role="status" aria-live="polite">
      <p class="lp-fet-t">Fetching entitlement data…</p>
      <div class="lp-fsteps">
        <!-- for each s in pSteps -->
          <span class="{lp-fstep [lp-now|lp-done]}"><span class="lp-dot"></span>{s.t}</span>
        <!-- /for -->
      </div>
      <div class="lp-ibar">
        <i style="--p: {pP}"></i>
      </div>
      <p class="lp-fet-s">This may take a moment for large applications.</p>
    </div>
  <!-- /if -->
  <!-- if pDone -->
    <section class="lp-rs lp-rz" style="--d: 0" aria-label="Results">
      <div class="lp-rhd">
        <div class="lp-rhd-n">
          <b class="lp-rhd-b">{pUsers}</b><span class="lp-rhd-l">{pUsersL}</span>
        </div>
        <span class="lp-kv3"><small>ITAM</small><b>{pItamV}</b></span><span class="lp-kv3"><small>Application</small><b>{pAppV}</b></span><span class="lp-grow"></span>
        <div class="lp-vseg" role="tablist" aria-label="View">
          <span class="lp-ind" style="transform: {pVX}"></span>
          <!-- for each v in pViews -->
            <button type="button" role="tab" class="{[lp-on]}" onClick={v.go}>{v.t}</button>
          <!-- /for -->
        </div>
        <div class="lp-xg" role="group" aria-label="Export">
          <span class="lp-xg-l"><Icon name="download" size="14" class="lp-dl"/>Export</span>
          <button type="button" onClick={pCsv}>CSV</button>
          <button type="button" onClick={pXls}>Excel</button>
          <button type="button" onClick={pJson}>JSON</button>
        </div>
      </div>
      <div class="lp-cd">
        <div class="lp-cd-h">
          <label class="lp-sr">
            <Icon name="search" size="16"/>
            <input type="search" value={pQ} onChange={onPQ} placeholder="Search users, FMIDs, entitlements" aria-label="Search users, FMIDs, entitlements">
          </label>
          <!-- for each filter you have today (same names, order, menus, logic) -->
            <span class="lp-ddg">
              <button type="button" class="lp-dd" onClick={your filter's open handler} aria-haspopup="listbox"><small>{filter label}</small>{current value}<Icon name="chevron-down" size="14" bold/></button>
              <button type="button" class="lp-inf" aria-label="About {filter label}"><Icon name="info" size="14"/></button><!-- wire your EXISTING tooltip to this trigger -->
            </span>
          <!-- /for -->
          <span class="lp-grow"></span><span class="lp-mono" style="font-size: 11.5px; color: var(--muted)">{pCount}</span>
        </div>
        <!-- if pDetail -->
          <div class="lp-cgs">
            <span class="lp-cgs-l">Columns</span>
            <!-- for each g in pGroups -->
              <button type="button" class="{lp-tg [lp-on]}" aria-pressed={g.on} onClick={g.go}>
                <span class="lp-ckb"><Icon name="check" size="11" bold/></span>{g.t}
              </button>
            <!-- /for -->
          </div>
        <!-- /if -->
        <!-- YOUR EXISTING Detail table (and, in the same way, your existing Matrix table with ALL its columns), with the dense adapter (sections 10.5, 10.6) -->
        <div class="lp-xt-wrap lp-xt-tall">
          <table class="{lp-xt lp-xt-dense lp-xt-sticky [lp-xt-grouped]}" aria-label={the app's label}>
            <thead>
              <!-- if the table has a group header row -->
                <tr>
                  <th class="lp-xt-gh lp-xt-stk" style="--c: transparent"></th>
                  <!-- for each g in your column groups -->
                    <th class="lp-xt-gh" colspan={g.columnCount} style="--c: {group colour}"><i></i>{g.title}</th>
                  <!-- /for -->
                </tr>
              <!-- /if -->
              <tr>
                <th class="lp-xt-th lp-xt-stk">{first column title, as today}</th>
                <!-- for each h in your columns (ALL of them) -->
                  <th class="{lp-xt-th [lp-xt-gs]}">{h.title}<!-- keep your resize / sort handles if the table has them --></th>
                <!-- /for -->
              </tr>
            </thead>
            <tbody class="{lp-xt-body [lp-lb]}">
              <!-- for each r in your rows -->
                <tr class="lp-xt-r" style="--i: {index}">
                  <td class="lp-xt-td lp-xt-stk">
                    <span class="lp-who"><span class="lp-mgx">{initials}</span><span><b>{user name}</b><small>{Bank ID}</small></span></span>
                  </td>
                  <!-- for each c in r's cells (ALL columns) -->
                    <td class="{lp-xt-td [lp-xt-gs]}">
                      <!-- TEXT --><span class="{lp-tt [lp-mono] [lp-dim]}">{value}</span>
                      <!-- LIST OF ENTITLEMENTS --><span class="lp-ent"><span class="lp-chp">{entitlement}</span><span class="lp-chp">{entitlement}</span></span>
                      <!-- YES / NO or TICK --><span class="{lp-yn [lp-y]}">{the app's value}</span>
                    </td>
                  <!-- /for -->
                </tr>
              <!-- /for -->
            </tbody>
          </table>
          <!-- if no rows match -->
            <div class="lp-emp">
              <p class="lp-emp-t">{the app's no-results text}</p>
            </div>
          <!-- /if -->
        </div>
      </div>
    </section>
  <!-- /if -->
<!-- /if -->
```

## B.11 Toast

PROMPT §6.10. `{toast}` = your message. Add `lp-show` while visible.

```html
<div class="{lp-toast [lp-show]}" role="status" aria-live="polite">
  <span class="lp-tck"><Icon name="check" size="14" bold/></span>{toast}<i class="lp-tbar"></i>
</div>
```

## Icons

```html
<svg class="lp-i [lp-b if bold] [extra classes]" width="{size}" height="{size}" viewBox="0 0 24 24" aria-hidden="true"><path d="{path}"></path></svg>
```

Stroke icons; the CSS sets fill none, stroke currentColor, width 1.75 (2.25 bold).

| Name | Path `d` |
|---|---|
| `arrow-right` | `M5 12h14M13 6l6 6-6 6` |
| `arrow-up` | `M12 19V5M6 11l6-6 6 6` |
| `box` | `M12 3 4 7v10l8 4 8-4V7zM4 7l8 4 8-4M12 11v10` |
| `check` | `M5 12.5l4.5 4.5L19 7.5` |
| `chevron-down` | `M6 9l6 6 6-6` |
| `chevron-left` | `M15 6l-6 6 6 6` |
| `chevron-right` | `M9 6l6 6-6 6` |
| `close` | `M6 6l12 12M18 6 6 18` |
| `columns` | `M4 5h16v14H4zM9.5 5v14M14.5 5v14` |
| `database` | `M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3` |
| `doc` | `M7 3h7l5 5v13H7zM14 3v5h5M10 13h6M10 17h6` |
| `download` | `M12 4v11M7 10l5 5 5-5M5 20h14` |
| `eye` | `M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z` |
| `grid` | `M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z` |
| `info` | `M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v6M12 7.5v.01` |
| `layers` | `M12 3 3 7.5l9 4.5 9-4.5zM3 12l9 4.5 9-4.5M3 16.5 12 21l9-4.5` |
| `pencil` | `M4 20h4L19 9l-4-4L4 16zM13.5 6.5l4 4` |
| `pin` | `M9 4h6l-1 6 4 3v2H6v-2l4-3zM12 15v6` |
| `plus` | `M12 5v14M5 12h14` |
| `refresh` | `M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7` |
| `search` | `M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4` |
| `server` | `M4 4h16v6H4zM4 14h16v6H4zM8 7h.01M8 17h.01` |
| `star` | `M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.5 9.7l5.9-.9z` |
| `trash` | `M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3` |
| `upload` | `M12 16V5M7 10l5-5 5 5M5 20h14` |
| `user` | `M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0` |
| `zap` | `M13 3 5 14h6l-1 7 8-11h-6z` |
